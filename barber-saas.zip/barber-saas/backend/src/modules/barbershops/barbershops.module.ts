import { Module } from '@nestjs/common';
import { BarbershopsController } from './barbershops.controller';
import { BarbershopsService } from './barbershops.service';
import { PublicController } from './public.controller';
import { AppointmentsModule } from '../appointments/appointments.module';

@Module({
  imports: [AppointmentsModule],
  controllers: [BarbershopsController, PublicController],
  providers: [BarbershopsService],
})
export class BarbershopsModule {}
