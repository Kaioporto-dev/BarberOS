// ==========================================
// common/guards/jwt-auth.guard.ts
// ==========================================
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}

// ==========================================
// common/guards/roles.guard.ts
// ==========================================
import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required) return true;
    const { user } = context.switchToHttp().getRequest();
    return required.includes(user?.role);
  }
}

// ==========================================
// common/guards/tenant.guard.ts
// ==========================================
import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';

@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const tenantId = request.params.barbershopId || request.body?.barbershopId;

    if (!tenantId) return true; // rota sem tenant explícito

    if (user.role === 'SUPER_ADMIN') return true;
    if (user.barbershopId !== tenantId) {
      throw new ForbiddenException('Acesso negado a este tenant');
    }
    return true;
  }
}
