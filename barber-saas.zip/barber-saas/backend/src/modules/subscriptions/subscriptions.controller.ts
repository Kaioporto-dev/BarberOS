import { Controller, Get, Post, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { SubscriptionsService } from './subscriptions.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('subscriptions')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'subscriptions', version: '1' })
export class SubscriptionsController {
  constructor(private readonly svc: SubscriptionsService) {}

  @Get('barbershop') getOwn(@CurrentUser() u: any) { return this.svc.getBarbershopSubscription(u.barbershopId); }
  @Get('clients/:clientId') getClient(@CurrentUser() u: any, @Param('clientId') cid: string) { return this.svc.getClientSubscriptions(u.barbershopId, cid); }
  @Post('clients') createClient(@Body() dto: any) { return this.svc.createClientSubscription(dto); }
}
