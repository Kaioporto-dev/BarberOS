import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Scissors, Clock, DollarSign, ChevronRight, ChevronLeft,
  Star, MapPin, Phone, Calendar, User, CheckCircle, Tag, Loader2,
} from 'lucide-react';
import dayjs from 'dayjs';
import 'dayjs/locale/pt-br';
import toast from 'react-hot-toast';
import { publicApi } from '../../services/api';
import clsx from 'clsx';

dayjs.locale('pt-br');

type Step = 'service' | 'employee' | 'datetime' | 'info' | 'confirm';

const STEPS: Step[] = ['service', 'employee', 'datetime', 'info', 'confirm'];

const stepLabels: Record<Step, string> = {
  service: 'Serviço', employee: 'Profissional', datetime: 'Data & Hora', info: 'Seus dados', confirm: 'Confirmação',
};

function ProgressBar({ currentStep }: { currentStep: Step }) {
  const idx = STEPS.indexOf(currentStep);
  return (
    <div className="flex items-center gap-1">
      {STEPS.map((s, i) => (
        <div key={s} className="flex items-center gap-1">
          <div className={clsx(
            'w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all',
            i < idx ? 'bg-green-500 text-white' : i === idx ? 'bg-brand-600 text-white shadow-glow' : 'bg-gray-100 dark:bg-dark-700 text-gray-400'
          )}>
            {i < idx ? <CheckCircle className="w-4 h-4" /> : i + 1}
          </div>
          {i < STEPS.length - 1 && (
            <div className={clsx('h-0.5 w-6 rounded-full transition-all', i < idx ? 'bg-green-500' : 'bg-gray-200 dark:bg-dark-600')} />
          )}
        </div>
      ))}
    </div>
  );
}

export default function BookingPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const [step, setStep] = useState<Step>('service');
  const [selected, setSelected] = useState({
    service: null as any,
    employee: null as any,
    date: dayjs().add(1, 'day').format('YYYY-MM-DD'),
    time: '',
    couponCode: '',
    clientName: '',
    clientPhone: '',
    clientEmail: '',
    notes: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [booking, setBooking] = useState<any>(null);

  const { data: shop, isLoading: loadingShop, error } = useQuery({
    queryKey: ['public-shop', slug],
    queryFn: () => publicApi.getBarbershop(slug!),
    enabled: !!slug,
  });

  const { data: slots, isLoading: loadingSlots } = useQuery({
    queryKey: ['public-slots', slug, selected.employee?.id, selected.date, selected.service?.id],
    queryFn: () => publicApi.getSlots(slug!, selected.employee.id, selected.date, selected.service.id),
    enabled: !!selected.employee && !!selected.date && !!selected.service,
  });

  // Week date picker
  const [weekStart, setWeekStart] = useState(dayjs().startOf('week'));
  const weekDays = Array.from({ length: 7 }, (_, i) => weekStart.add(i, 'day'));

  const go = (s: Step) => setStep(s);
  const next = () => { const idx = STEPS.indexOf(step); if (idx < STEPS.length - 1) setStep(STEPS[idx + 1]); };
  const back = () => { const idx = STEPS.indexOf(step); if (idx > 0) setStep(STEPS[idx - 1]); };

  const handleBook = async () => {
    setSubmitting(true);
    try {
      const result = await publicApi.createBooking(slug!, {
        serviceId: selected.service.id,
        employeeId: selected.employee.id,
        startAt: `${selected.date}T${selected.time}`,
        clientName: selected.clientName,
        clientPhone: selected.clientPhone,
        clientEmail: selected.clientEmail,
        notes: selected.notes,
        couponCode: selected.couponCode || undefined,
      });
      setBooking(result);
      setStep('confirm');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Erro ao realizar agendamento');
    } finally { setSubmitting(false); }
  };

  if (loadingShop) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-dark-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    );
  }

  if (error || !shop) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <Scissors className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-gray-800 mb-2">Barbearia não encontrada</h1>
          <p className="text-gray-400">Verifique o link e tente novamente</p>
        </div>
      </div>
    );
  }

  const primaryColor = shop.primaryColor || '#1a1a2e';
  const accentColor = shop.accentColor || '#e94560';

  return (
    <div className="min-h-screen" style={{ background: `linear-gradient(135deg, ${primaryColor} 0%, ${primaryColor}dd 100%)` }}>
      {/* Hero */}
      <div className="relative overflow-hidden">
        {shop.coverUrl && (
          <img src={shop.coverUrl} alt={shop.name} className="absolute inset-0 w-full h-full object-cover opacity-20" />
        )}
        <div className="relative px-4 pt-12 pb-8 text-center">
          {shop.logoUrl ? (
            <img src={shop.logoUrl} alt={shop.name} className="w-20 h-20 rounded-2xl mx-auto mb-4 object-cover shadow-xl" />
          ) : (
            <div className="w-20 h-20 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-xl" style={{ background: accentColor }}>
              <Scissors className="w-10 h-10 text-white" />
            </div>
          )}
          <h1 className="font-display text-3xl font-bold text-white mb-1">{shop.name}</h1>
          {shop.description && <p className="text-white/70 text-sm max-w-sm mx-auto">{shop.description}</p>}
          <div className="flex items-center justify-center gap-4 mt-3">
            {shop.city && (
              <div className="flex items-center gap-1 text-white/60 text-xs">
                <MapPin className="w-3.5 h-3.5" />{shop.city}, {shop.state}
              </div>
            )}
            {shop.phone && (
              <div className="flex items-center gap-1 text-white/60 text-xs">
                <Phone className="w-3.5 h-3.5" />{shop.phone}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Booking card */}
      <div className="max-w-lg mx-auto px-4 pb-12">
        {step !== 'confirm' && (
          <div className="card p-6 shadow-2xl">
            {/* Progress */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-xs text-gray-400 mb-0.5">Passo {STEPS.indexOf(step) + 1} de {STEPS.length}</p>
                <p className="font-bold text-gray-900 dark:text-white">{stepLabels[step]}</p>
              </div>
              <ProgressBar currentStep={step} />
            </div>

            {/* STEP: Service */}
            {step === 'service' && (
              <div className="space-y-3">
                {shop.services?.map((s: any) => (
                  <button
                    key={s.id}
                    onClick={() => { setSelected(p => ({ ...p, service: s, time: '' })); next(); }}
                    className={clsx(
                      'w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-left',
                      selected.service?.id === s.id
                        ? 'border-brand-500 bg-brand-50 dark:bg-brand-950/20'
                        : 'border-gray-200 dark:border-dark-600 hover:border-gray-300 dark:hover:border-dark-500'
                    )}
                  >
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: accentColor + '20' }}>
                      <Scissors className="w-5 h-5" style={{ color: accentColor }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 dark:text-white">{s.name}</p>
                      {s.description && <p className="text-xs text-gray-400 truncate">{s.description}</p>}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-bold text-brand-600 dark:text-brand-400">R$ {s.price?.toFixed(2)}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-400"><Clock className="w-3 h-3" />{s.duration}min</div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* STEP: Employee */}
            {step === 'employee' && (
              <div className="space-y-3">
                {shop.employees?.map((e: any) => (
                  <button
                    key={e.id}
                    onClick={() => { setSelected(p => ({ ...p, employee: e, time: '' })); next(); }}
                    className={clsx(
                      'w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-left',
                      selected.employee?.id === e.id
                        ? 'border-brand-500 bg-brand-50 dark:bg-brand-950/20'
                        : 'border-gray-200 dark:border-dark-600 hover:border-gray-300'
                    )}
                  >
                    <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0" style={{ background: accentColor }}>
                      {e.name?.[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 dark:text-white">{e.name}</p>
                      {e.bio && <p className="text-xs text-gray-400 truncate">{e.bio}</p>}
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}

            {/* STEP: Date & Time */}
            {step === 'datetime' && (
              <div className="space-y-4">
                {/* Week picker */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <button onClick={() => setWeekStart(w => w.subtract(1, 'week'))} className="p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700"><ChevronLeft className="w-4 h-4" /></button>
                    <span className="text-sm font-semibold text-gray-700 dark:text-gray-300 capitalize">
                      {weekStart.format('MMMM YYYY')}
                    </span>
                    <button onClick={() => setWeekStart(w => w.add(1, 'week'))} className="p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {weekDays.map(d => {
                      const isPast = d.isBefore(dayjs(), 'day');
                      const isSelected = d.format('YYYY-MM-DD') === selected.date;
                      return (
                        <button
                          key={d.format('YYYY-MM-DD')}
                          disabled={isPast}
                          onClick={() => { setSelected(p => ({ ...p, date: d.format('YYYY-MM-DD'), time: '' })); }}
                          className={clsx(
                            'flex flex-col items-center py-2 rounded-xl text-xs transition-all',
                            isSelected ? 'text-white shadow-glow' : isPast ? 'opacity-30 cursor-not-allowed text-gray-400' : 'hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-600 dark:text-gray-300'
                          )}
                          style={isSelected ? { background: accentColor } : {}}
                        >
                          <span className="text-[10px] uppercase">{d.format('ddd')}</span>
                          <span className="font-bold text-sm">{d.format('D')}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Time slots */}
                <div>
                  <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Horários disponíveis</p>
                  {loadingSlots ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-brand-500" />
                    </div>
                  ) : (
                    <div className="grid grid-cols-4 gap-2">
                      {slots?.filter((s: any) => s.available).map((s: any) => (
                        <button
                          key={s.time}
                          onClick={() => setSelected(p => ({ ...p, time: s.time }))}
                          className={clsx(
                            'py-2.5 rounded-xl text-sm font-semibold border-2 transition-all',
                            selected.time === s.time
                              ? 'text-white border-transparent shadow-sm'
                              : 'border-gray-200 dark:border-dark-600 text-gray-600 dark:text-gray-300 hover:border-brand-400'
                          )}
                          style={selected.time === s.time ? { background: accentColor, borderColor: accentColor } : {}}
                        >
                          {s.time}
                        </button>
                      ))}
                      {slots?.filter((s: any) => s.available).length === 0 && !loadingSlots && (
                        <p className="col-span-4 text-center text-sm text-gray-400 py-6">Nenhum horário disponível neste dia</p>
                      )}
                    </div>
                  )}
                </div>

                <button
                  onClick={next}
                  disabled={!selected.time}
                  className="btn-primary w-full justify-center py-3"
                  style={selected.time ? { background: accentColor } : {}}
                >
                  Continuar <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* STEP: Client Info */}
            {step === 'info' && (
              <div className="space-y-4">
                <div>
                  <label className="label">Seu nome completo</label>
                  <input
                    value={selected.clientName}
                    onChange={e => setSelected(p => ({ ...p, clientName: e.target.value }))}
                    className="input"
                    placeholder="João Silva"
                  />
                </div>
                <div>
                  <label className="label">WhatsApp / Telefone</label>
                  <input
                    value={selected.clientPhone}
                    onChange={e => setSelected(p => ({ ...p, clientPhone: e.target.value }))}
                    className="input"
                    placeholder="(11) 99999-9999"
                    type="tel"
                  />
                </div>
                <div>
                  <label className="label">E-mail (opcional)</label>
                  <input
                    value={selected.clientEmail}
                    onChange={e => setSelected(p => ({ ...p, clientEmail: e.target.value }))}
                    className="input"
                    placeholder="joao@email.com"
                    type="email"
                  />
                </div>
                <div>
                  <label className="label">Cupom de desconto (opcional)</label>
                  <div className="flex gap-2">
                    <input
                      value={selected.couponCode}
                      onChange={e => setSelected(p => ({ ...p, couponCode: e.target.value.toUpperCase() }))}
                      className="input font-mono"
                      placeholder="PRIMEIRAVISITA"
                    />
                  </div>
                </div>
                <div>
                  <label className="label">Observações (opcional)</label>
                  <textarea
                    value={selected.notes}
                    onChange={e => setSelected(p => ({ ...p, notes: e.target.value }))}
                    rows={2}
                    className="input resize-none"
                    placeholder="Alguma preferência ou observação..."
                  />
                </div>

                {/* Summary */}
                <div className="rounded-xl p-4 space-y-2" style={{ background: primaryColor + '15' }}>
                  <p className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Resumo</p>
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Serviço</span>
                      <span className="font-medium">{selected.service?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Profissional</span>
                      <span className="font-medium">{selected.employee?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Data & Hora</span>
                      <span className="font-medium">{dayjs(selected.date).format('DD/MM')} às {selected.time}</span>
                    </div>
                    <div className="flex justify-between font-bold pt-1 border-t border-gray-200 dark:border-dark-600">
                      <span>Total</span>
                      <span style={{ color: accentColor }}>R$ {selected.service?.price?.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleBook}
                  disabled={!selected.clientName || !selected.clientPhone || submitting}
                  className="btn-primary w-full justify-center py-3"
                  style={selected.clientName && selected.clientPhone ? { background: accentColor } : {}}
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><CheckCircle className="w-4 h-4" />Confirmar agendamento</>}
                </button>
              </div>
            )}

            {/* Back button */}
            {step !== 'service' && step !== 'confirm' && (
              <button onClick={back} className="btn-ghost w-full justify-center mt-3 text-sm">
                <ChevronLeft className="w-4 h-4" /> Voltar
              </button>
            )}
          </div>
        )}

        {/* STEP: Confirmation */}
        {step === 'confirm' && booking && (
          <div className="card p-8 text-center shadow-2xl animate-slide-up">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="font-display text-2xl font-bold text-gray-900 dark:text-white mb-2">Agendamento confirmado!</h2>
            <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
              Você receberá uma confirmação via WhatsApp em breve.
            </p>

            <div className="rounded-xl p-5 space-y-3 mb-6 text-left" style={{ background: primaryColor + '10' }}>
              {[
                { icon: Scissors, label: 'Serviço', value: booking.service?.name || selected.service?.name },
                { icon: User, label: 'Profissional', value: booking.employee?.name || selected.employee?.name },
                { icon: Calendar, label: 'Data', value: dayjs(booking.startAt).format('DD/MM/YYYY') },
                { icon: Clock, label: 'Horário', value: dayjs(booking.startAt).format('HH:mm') },
                { icon: DollarSign, label: 'Valor', value: `R$ ${booking.finalPrice?.toFixed(2)}` },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: accentColor + '20' }}>
                    <Icon className="w-4 h-4" style={{ color: accentColor }} />
                  </div>
                  <div className="flex-1 flex justify-between text-sm">
                    <span className="text-gray-500">{label}</span>
                    <span className="font-semibold text-gray-800 dark:text-gray-200">{value}</span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => { setStep('service'); setSelected(s => ({ ...s, service: null, employee: null, time: '' })); setBooking(null); }}
              className="btn-primary w-full justify-center py-3"
              style={{ background: accentColor }}
            >
              Fazer outro agendamento
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
