import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Edit2, Trash2, Phone, Star, X, Loader2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import { employeesApi } from '../../services/api';

const schema = z.object({
  name: z.string().min(2, 'Nome obrigatório'),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  bio: z.string().optional(),
  commission: z.coerce.number().min(0).max(100).default(40),
});
type FormData = z.infer<typeof schema>;

function EmployeeModal({ employee, onClose, onSuccess }: any) {
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: employee?.name || '', phone: employee?.phone || '',
      email: employee?.email || '', bio: employee?.bio || '',
      commission: employee?.commission || 40,
    },
  });
  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      if (employee) await employeesApi.update(employee.id, data);
      else await employeesApi.create(data);
      toast.success(employee ? 'Profissional atualizado!' : 'Profissional cadastrado!');
      onSuccess();
    } catch (err: any) { toast.error(err.response?.data?.message || 'Erro'); }
    finally { setLoading(false); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-dark-700">
          <h2 className="section-title">{employee ? 'Editar profissional' : 'Novo profissional'}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div><label className="label">Nome completo</label><input {...register('name')} className="input" placeholder="Carlos Eduardo" />{errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}</div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Telefone</label><input {...register('phone')} className="input" placeholder="(11) 99999-9999" /></div>
            <div><label className="label">E-mail</label><input {...register('email')} type="email" className="input" /></div>
          </div>
          <div><label className="label">Comissão padrão (%)</label><input {...register('commission')} type="number" className="input" /><p className="text-xs text-gray-400 mt-1">Percentual recebido por serviço realizado</p></div>
          <div><label className="label">Bio / Especialidades</label><textarea {...register('bio')} rows={3} className="input resize-none" placeholder="Especialista em degradê, coloração..." /></div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancelar</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Salvar'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function EmployeesPage() {
  const [modal, setModal] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ['employees'], queryFn: () => employeesApi.list() });

  const handleSuccess = () => { qc.invalidateQueries({ queryKey: ['employees'] }); setModal(false); setSelected(null); };
  const handleDelete = async (e: any) => {
    if (!confirm(`Excluir "${e.name}"?`)) return;
    try { await employeesApi.delete(e.id); toast.success('Excluído!'); qc.invalidateQueries({ queryKey: ['employees'] }); } catch { toast.error('Erro'); }
  };

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Profissionais</h1>
        <button className="btn-primary" onClick={() => { setSelected(null); setModal(true); }}><Plus className="w-4 h-4" />Novo profissional</button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? Array(3).fill(0).map((_, i) => <div key={i} className="card p-6 h-44 animate-pulse bg-gray-50 dark:bg-dark-700" />) :
          data?.items?.map((emp: any) => (
            <div key={emp.id} className="card p-6 flex flex-col gap-4 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white text-lg font-bold flex-shrink-0">
                    {emp.name?.[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white leading-tight">{emp.name}</h3>
                    {emp.phone && <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5"><Phone className="w-3 h-3" />{emp.phone}</p>}
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => { setSelected(emp); setModal(true); }} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30"><Edit2 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => handleDelete(emp)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>

              {emp.bio && <p className="text-sm text-gray-500 dark:text-gray-400">{emp.bio}</p>}

              <div className="flex items-center justify-between pt-2 border-t border-gray-100 dark:border-dark-700">
                <div className="flex items-center gap-1.5 text-sm">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="font-semibold text-gray-700 dark:text-gray-300">{emp.commission}% comissão</span>
                </div>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${emp.isActive ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-gray-100 text-gray-500'}`}>
                  {emp.isActive ? 'Ativo' : 'Inativo'}
                </span>
              </div>
            </div>
          ))}
      </div>

      {modal && <EmployeeModal employee={selected} onClose={() => { setModal(false); setSelected(null); }} onSuccess={handleSuccess} />}
    </div>
  );
}
