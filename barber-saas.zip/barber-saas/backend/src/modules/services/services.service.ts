import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ServicesService {
  constructor(private prisma: PrismaService) {}

  async findAll(barbershopId: string, { isActive }: any = {}) {
    const where: any = { barbershopId };
    if (isActive !== undefined) where.isActive = isActive === 'true' || isActive === true;
    const items = await this.prisma.service.findMany({ where, orderBy: { position: 'asc' } });
    return { total: items.length, items };
  }

  async create(barbershopId: string, dto: any) {
    return this.prisma.service.create({ data: { ...dto, barbershopId } });
  }

  async update(barbershopId: string, id: string, dto: any) {
    const s = await this.prisma.service.findFirst({ where: { id, barbershopId } });
    if (!s) throw new NotFoundException('Serviço não encontrado');
    return this.prisma.service.update({ where: { id }, data: dto });
  }

  async delete(barbershopId: string, id: string) {
    const s = await this.prisma.service.findFirst({ where: { id, barbershopId } });
    if (!s) throw new NotFoundException('Serviço não encontrado');
    return this.prisma.service.update({ where: { id }, data: { isActive: false } });
  }
}
