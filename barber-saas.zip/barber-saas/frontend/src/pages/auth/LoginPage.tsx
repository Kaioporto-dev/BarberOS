import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { authApi } from '../../services/api';
import { useAuthStore } from '../../store/auth.store';

const schema = z.object({
  email: z.string().email('E-mail inválido'),
  password: z.string().min(1, 'Senha obrigatória'),
});

type FormData = z.infer<typeof schema>;

export default function LoginPage() {
  const [showPw, setShowPw] = useState(false);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { email: 'admin@demo.com', password: 'Demo@1234' },
  });

  const onSubmit = async (data: FormData) => {
    try {
      const result = await authApi.login(data);
      setAuth(result);
      toast.success(`Bem-vindo, ${result.user.name}!`);
      navigate('/admin/dashboard');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Credenciais inválidas');
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-1">Entrar no painel</h2>
      <p className="text-sm text-gray-400 mb-6">Gerencie sua barbearia com inteligência</p>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="label text-gray-300">E-mail</label>
          <input
            {...register('email')}
            type="email"
            className="input bg-dark-700 border-dark-500 text-white placeholder-gray-500 focus:ring-brand-500"
            placeholder="seu@email.com"
          />
          {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email.message}</p>}
        </div>

        <div>
          <label className="label text-gray-300">Senha</label>
          <div className="relative">
            <input
              {...register('password')}
              type={showPw ? 'text' : 'password'}
              className="input bg-dark-700 border-dark-500 text-white placeholder-gray-500 focus:ring-brand-500 pr-12"
              placeholder="••••••••"
            />
            <button
              type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200"
              onClick={() => setShowPw(!showPw)}
            >
              {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password.message}</p>}
        </div>

        <button type="submit" disabled={isSubmitting} className="btn-primary w-full justify-center py-3">
          {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Entrar'}
        </button>
      </form>

      <p className="text-center text-sm text-gray-500 mt-6">
        Não tem conta?{' '}
        <Link to="/admin/register" className="text-brand-400 hover:text-brand-300 font-medium">
          Cadastre sua barbearia
        </Link>
      </p>

      {/* Demo hint */}
      <div className="mt-4 p-3 rounded-xl bg-brand-950/40 border border-brand-900/50">
        <p className="text-xs text-brand-300 text-center">
          Demo: <span className="font-mono">admin@demo.com</span> / <span className="font-mono">Demo@1234</span>
        </p>
      </div>
    </div>
  );
}
