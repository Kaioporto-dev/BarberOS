import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SubscriptionsService {
  constructor(private prisma: PrismaService) {}

  async getBarbershopSubscription(barbershopId: string) {
    return this.prisma.barbershopSubscription.findFirst({
      where: { barbershopId }, orderBy: { createdAt: 'desc' },
    });
  }

  async getClientSubscriptions(barbershopId: string, clientId: string) {
    return this.prisma.clientSubscription.findMany({
      where: { clientId, client: { barbershopId } },
    });
  }

  async createClientSubscription(dto: any) {
    return this.prisma.clientSubscription.create({ data: dto });
  }
}
