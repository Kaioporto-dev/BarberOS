import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AppointmentsService } from './appointments.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('appointments')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'appointments', version: '1' })
export class AppointmentsController {
  constructor(private readonly svc: AppointmentsService) {}

  @Post()
  create(@CurrentUser() user: any, @Body() dto: any) { return this.svc.create(user.barbershopId, dto); }

  @Get()
  findAll(@CurrentUser() user: any, @Query() q: any) { return this.svc.findAll(user.barbershopId, q); }

  @Get('available-slots')
  getSlots(@CurrentUser() u: any, @Query('employeeId') emp: string, @Query('date') date: string, @Query('serviceId') svc: string) {
    return this.svc.getAvailableSlots(u.barbershopId, emp, date, svc);
  }

  @Get(':id')
  findOne(@CurrentUser() user: any, @Param('id') id: string) { return this.svc.findOne(user.barbershopId, id); }

  @Patch(':id')
  update(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: any) { return this.svc.update(user.barbershopId, id, dto); }

  @Patch(':id/status')
  updateStatus(@CurrentUser() u: any, @Param('id') id: string, @Body('status') status: string, @Body('reason') reason?: string) {
    return this.svc.updateStatus(u.barbershopId, id, status, reason);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@CurrentUser() u: any, @Param('id') id: string) { return this.svc.update(u.barbershopId, id, { status: 'CANCELLED' }); }
}
