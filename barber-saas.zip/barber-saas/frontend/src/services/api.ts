import axios from 'axios';
import { useAuthStore } from '../store/auth.store';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000';

export const api = axios.create({
  baseURL: `${API_URL}/api/v1`,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor — inject token
api.interceptors.request.use((config) => {
  const { accessToken } = useAuthStore.getState();
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

// Response interceptor — handle refresh
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;

    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      const { refreshToken, setAuth, logout } = useAuthStore.getState();

      if (refreshToken) {
        try {
          const { data } = await axios.post(`${API_URL}/api/v1/auth/refresh`, { refreshToken });
          const { accessToken: newAccess, refreshToken: newRefresh, user, barbershop } = data.data;
          setAuth({ user, barbershop, accessToken: newAccess, refreshToken: newRefresh });
          original.headers.Authorization = `Bearer ${newAccess}`;
          return api(original);
        } catch {
          logout();
          window.location.href = '/admin/login';
        }
      } else {
        logout();
        window.location.href = '/admin/login';
      }
    }

    return Promise.reject(error);
  }
);

// ──────────────────────────────────────────────
// Auth
// ──────────────────────────────────────────────
export const authApi = {
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data).then(r => r.data.data),
  register: (data: any) =>
    api.post('/auth/register', data).then(r => r.data.data),
  logout: (refreshToken: string) =>
    api.post('/auth/logout', { refreshToken }),
  me: () => api.get('/auth/me').then(r => r.data.data),
};

// ──────────────────────────────────────────────
// Appointments
// ──────────────────────────────────────────────
export const appointmentsApi = {
  list: (params?: any) =>
    api.get('/appointments', { params }).then(r => r.data.data),
  get: (id: string) =>
    api.get(`/appointments/${id}`).then(r => r.data.data),
  create: (data: any) =>
    api.post('/appointments', data).then(r => r.data.data),
  update: (id: string, data: any) =>
    api.patch(`/appointments/${id}`, data).then(r => r.data.data),
  updateStatus: (id: string, status: string, reason?: string) =>
    api.patch(`/appointments/${id}/status`, { status, reason }).then(r => r.data.data),
  delete: (id: string) =>
    api.delete(`/appointments/${id}`),
  getSlots: (employeeId: string, date: string, serviceId: string) =>
    api.get('/appointments/available-slots', { params: { employeeId, date, serviceId } }).then(r => r.data.data),
};

// ──────────────────────────────────────────────
// Clients
// ──────────────────────────────────────────────
export const clientsApi = {
  list: (params?: any) =>
    api.get('/clients', { params }).then(r => r.data.data),
  get: (id: string) =>
    api.get(`/clients/${id}`).then(r => r.data.data),
  create: (data: any) =>
    api.post('/clients', data).then(r => r.data.data),
  update: (id: string, data: any) =>
    api.patch(`/clients/${id}`, data).then(r => r.data.data),
  delete: (id: string) =>
    api.delete(`/clients/${id}`),
  getHistory: (id: string) =>
    api.get(`/clients/${id}/appointments`).then(r => r.data.data),
};

// ──────────────────────────────────────────────
// Services
// ──────────────────────────────────────────────
export const servicesApi = {
  list: (params?: any) =>
    api.get('/services', { params }).then(r => r.data.data),
  create: (data: any) =>
    api.post('/services', data).then(r => r.data.data),
  update: (id: string, data: any) =>
    api.patch(`/services/${id}`, data).then(r => r.data.data),
  delete: (id: string) =>
    api.delete(`/services/${id}`),
};

// ──────────────────────────────────────────────
// Employees
// ──────────────────────────────────────────────
export const employeesApi = {
  list: (params?: any) =>
    api.get('/employees', { params }).then(r => r.data.data),
  get: (id: string) =>
    api.get(`/employees/${id}`).then(r => r.data.data),
  create: (data: any) =>
    api.post('/employees', data).then(r => r.data.data),
  update: (id: string, data: any) =>
    api.patch(`/employees/${id}`, data).then(r => r.data.data),
  delete: (id: string) =>
    api.delete(`/employees/${id}`),
};

// ──────────────────────────────────────────────
// Reports / Dashboard
// ──────────────────────────────────────────────
export const reportsApi = {
  dashboard: () =>
    api.get('/reports/dashboard').then(r => r.data.data),
  revenue: (startDate: string, endDate: string) =>
    api.get('/reports/revenue', { params: { startDate, endDate } }).then(r => r.data.data),
  topEmployees: (params?: any) =>
    api.get('/reports/top-employees', { params }).then(r => r.data.data),
  topServices: (params?: any) =>
    api.get('/reports/top-services', { params }).then(r => r.data.data),
  bestDays: () =>
    api.get('/reports/best-days').then(r => r.data.data),
  averageTicket: () =>
    api.get('/reports/average-ticket').then(r => r.data.data),
  dailyCashFlow: (date: string) =>
    api.get('/reports/cash-flow', { params: { date } }).then(r => r.data.data),
  inactiveClients: (days?: number) =>
    api.get('/reports/inactive-clients', { params: { days } }).then(r => r.data.data),
};

// ──────────────────────────────────────────────
// Payments
// ──────────────────────────────────────────────
export const paymentsApi = {
  list: (params?: any) =>
    api.get('/payments', { params }).then(r => r.data.data),
  create: (data: any) =>
    api.post('/payments', data).then(r => r.data.data),
  update: (id: string, data: any) =>
    api.patch(`/payments/${id}`, data).then(r => r.data.data),
};

// ──────────────────────────────────────────────
// Coupons
// ──────────────────────────────────────────────
export const couponsApi = {
  list: () =>
    api.get('/coupons').then(r => r.data.data),
  create: (data: any) =>
    api.post('/coupons', data).then(r => r.data.data),
  update: (id: string, data: any) =>
    api.patch(`/coupons/${id}`, data).then(r => r.data.data),
  delete: (id: string) =>
    api.delete(`/coupons/${id}`),
  validate: (code: string) =>
    api.post('/coupons/validate', { code }).then(r => r.data.data),
};

// ──────────────────────────────────────────────
// Public (no auth)
// ──────────────────────────────────────────────
export const publicApi = {
  getBarbershop: (slug: string) =>
    axios.get(`${API_URL}/api/v1/public/${slug}`).then(r => r.data.data),
  getSlots: (slug: string, employeeId: string, date: string, serviceId: string) =>
    axios.get(`${API_URL}/api/v1/public/${slug}/slots`, { params: { employeeId, date, serviceId } }).then(r => r.data.data),
  createBooking: (slug: string, data: any) =>
    axios.post(`${API_URL}/api/v1/public/${slug}/book`, data).then(r => r.data.data),
  getClientHistory: (slug: string, phone: string) =>
    axios.get(`${API_URL}/api/v1/public/${slug}/history`, { params: { phone } }).then(r => r.data.data),
};
