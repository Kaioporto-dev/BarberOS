import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Filter, CheckCircle, XCircle, Clock } from 'lucide-react';
import dayjs from 'dayjs';
import toast from 'react-hot-toast';
import clsx from 'clsx';
import { appointmentsApi, employeesApi } from '../../services/api';
import AppointmentModal from '../../components/admin/AppointmentModal';

const statusConfig: Record<string, { label: string; cls: string }> = {
  PENDING:     { label: 'Pendente',       cls: 'status-pending' },
  CONFIRMED:   { label: 'Confirmado',     cls: 'status-confirmed' },
  IN_PROGRESS: { label: 'Em andamento',   cls: 'status-in_progress' },
  COMPLETED:   { label: 'Concluído',      cls: 'status-completed' },
  CANCELLED:   { label: 'Cancelado',      cls: 'status-cancelled' },
  NO_SHOW:     { label: 'Não compareceu', cls: 'status-no_show' },
};

export default function AppointmentsPageImpl() {
  const [modal, setModal] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const [filters, setFilters] = useState({
    date: dayjs().format('YYYY-MM-DD'),
    status: '',
    employeeId: '',
  });
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['appointments', 'list', filters],
    queryFn: () => appointmentsApi.list({ ...filters, limit: 100 }),
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => employeesApi.list({ isActive: true }),
  });

  const handleSuccess = () => {
    setModal(false);
    setSelected(null);
    qc.invalidateQueries({ queryKey: ['appointments'] });
  };

  const handleQuickStatus = async (id: string, status: string) => {
    try {
      await appointmentsApi.updateStatus(id, status);
      toast.success('Status atualizado!');
      qc.invalidateQueries({ queryKey: ['appointments'] });
    } catch { toast.error('Erro ao atualizar'); }
  };

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Agendamentos</h1>
        <button className="btn-primary" onClick={() => { setSelected(null); setModal(true); }}>
          <Plus className="w-4 h-4" /> Novo agendamento
        </button>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-wrap gap-3">
        <input
          type="date"
          value={filters.date}
          onChange={e => setFilters(f => ({ ...f, date: e.target.value }))}
          className="input w-auto py-2 text-sm"
        />
        <select
          value={filters.status}
          onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}
          className="input w-auto py-2 text-sm"
        >
          <option value="">Todos os status</option>
          {Object.entries(statusConfig).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
        <select
          value={filters.employeeId}
          onChange={e => setFilters(f => ({ ...f, employeeId: e.target.value }))}
          className="input w-auto py-2 text-sm"
        >
          <option value="">Todos os profissionais</option>
          {employees?.items?.map((e: any) => (
            <option key={e.id} value={e.id}>{e.name}</option>
          ))}
        </select>
        <button
          onClick={() => setFilters({ date: dayjs().format('YYYY-MM-DD'), status: '', employeeId: '' })}
          className="btn-ghost text-sm py-2"
        >
          Limpar filtros
        </button>
        {data?.total !== undefined && (
          <span className="ml-auto text-sm text-gray-500 dark:text-gray-400 self-center">
            {data.total} agendamento{data.total !== 1 ? 's' : ''}
          </span>
        )}
      </div>

      {/* Table */}
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th>Horário</th>
              <th>Cliente</th>
              <th>Serviço</th>
              <th className="hidden md:table-cell">Profissional</th>
              <th>Valor</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array(8).fill(0).map((_, i) => (
                <tr key={i}>{Array(7).fill(0).map((_, j) => (
                  <td key={j}><div className="h-4 bg-gray-100 dark:bg-dark-700 rounded animate-pulse" /></td>
                ))}</tr>
              ))
            ) : data?.items?.map((apt: any) => {
              const st = statusConfig[apt.status] || { label: apt.status, cls: '' };
              return (
                <tr key={apt.id} className="cursor-pointer" onClick={() => { setSelected(apt); setModal(true); }}>
                  <td>
                    <p className="font-bold text-gray-900 dark:text-white">{dayjs(apt.startAt).format('HH:mm')}</p>
                    <p className="text-xs text-gray-400">{apt.service?.duration}min</p>
                  </td>
                  <td>
                    <p className="font-medium text-gray-800 dark:text-gray-200">{apt.client?.name}</p>
                    <p className="text-xs text-gray-400">{apt.client?.phone}</p>
                  </td>
                  <td className="text-gray-600 dark:text-gray-300">{apt.service?.name}</td>
                  <td className="hidden md:table-cell text-gray-500">{apt.employee?.name}</td>
                  <td className="font-bold text-brand-600 dark:text-brand-400">
                    R$ {apt.finalPrice?.toFixed(2)}
                    {apt.discount > 0 && (
                      <p className="text-xs text-green-500 font-normal">-R$ {apt.discount?.toFixed(2)}</p>
                    )}
                  </td>
                  <td><span className={clsx('status-badge', st.cls)}>{st.label}</span></td>
                  <td onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1">
                      {apt.status === 'PENDING' && (
                        <button
                          onClick={() => handleQuickStatus(apt.id, 'CONFIRMED')}
                          className="p-1.5 rounded-lg text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30"
                          title="Confirmar"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                      )}
                      {['PENDING','CONFIRMED'].includes(apt.status) && (
                        <button
                          onClick={() => handleQuickStatus(apt.id, 'COMPLETED')}
                          className="p-1.5 rounded-lg text-green-500 hover:bg-green-50 dark:hover:bg-green-950/30"
                          title="Concluir"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                      )}
                      {!['CANCELLED','COMPLETED'].includes(apt.status) && (
                        <button
                          onClick={() => handleQuickStatus(apt.id, 'CANCELLED')}
                          className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
                          title="Cancelar"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {!isLoading && data?.items?.length === 0 && (
          <div className="text-center py-12">
            <Clock className="w-10 h-10 text-gray-300 dark:text-dark-600 mx-auto mb-2" />
            <p className="text-gray-400">Nenhum agendamento encontrado</p>
          </div>
        )}
      </div>

      {modal && (
        <AppointmentModal
          appointment={selected}
          onClose={() => { setModal(false); setSelected(null); }}
          onSuccess={handleSuccess}
        />
      )}
    </div>
  );
}
