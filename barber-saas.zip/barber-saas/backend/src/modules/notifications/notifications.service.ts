import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { Cron, CronExpression } from '@nestjs/schedule';
import * as dayjs from 'dayjs';
import axios from 'axios';

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
  ) {}

  async sendConfirmation(appointment: any) {
    const message = this.buildMessage('CONFIRMATION', appointment);
    await this.send(appointment, 'CONFIRMATION', message);
  }

  async sendCancellation(appointment: any) {
    const message = this.buildMessage('CANCELLATION', appointment);
    await this.send(appointment, 'CANCELLATION', message);
  }

  async sendReminder(appointment: any, type: '24H' | '1H') {
    const notifType = type === '24H' ? 'REMINDER_24H' : 'REMINDER_1H';
    const message = this.buildMessage(notifType, appointment);
    await this.send(appointment, notifType, message);
  }

  async sendReviewRequest(appointment: any) {
    const message = this.buildMessage('REVIEW_REQUEST', appointment);
    await this.send(appointment, 'REVIEW_REQUEST', message);
  }

  @Cron('0 * * * *') // a cada hora
  async processReminders() {
    const now = dayjs();
    const in24h = now.add(24, 'hour');
    const in1h = now.add(1, 'hour');

    // Lembretes 24h
    const apts24h = await this.prisma.appointment.findMany({
      where: {
        status: { in: ['CONFIRMED', 'PENDING'] },
        startAt: {
          gte: in24h.subtract(30, 'minute').toDate(),
          lte: in24h.add(30, 'minute').toDate(),
        },
      },
      include: { client: true, employee: true, service: true, barbershop: true },
    });

    for (const apt of apts24h) {
      const alreadySent = await this.prisma.notificationLog.findFirst({
        where: { appointmentId: apt.id, type: 'REMINDER_24H' },
      });
      if (!alreadySent) await this.sendReminder(apt, '24H');
    }

    // Lembretes 1h
    const apts1h = await this.prisma.appointment.findMany({
      where: {
        status: { in: ['CONFIRMED', 'PENDING'] },
        startAt: {
          gte: in1h.subtract(10, 'minute').toDate(),
          lte: in1h.add(10, 'minute').toDate(),
        },
      },
      include: { client: true, employee: true, service: true, barbershop: true },
    });

    for (const apt of apts1h) {
      const alreadySent = await this.prisma.notificationLog.findFirst({
        where: { appointmentId: apt.id, type: 'REMINDER_1H' },
      });
      if (!alreadySent) await this.sendReminder(apt, '1H');
    }
  }

  @Cron(CronExpression.EVERY_DAY_AT_10AM)
  async sendReactivationMessages() {
    const cutoff = dayjs().subtract(45, 'day').toDate();

    const inactiveClients = await this.prisma.client.findMany({
      where: {
        isActive: true,
        lastVisitAt: { lte: cutoff },
      },
      include: { barbershop: true },
      take: 50,
    });

    for (const client of inactiveClients) {
      const alreadySent = await this.prisma.notificationLog.findFirst({
        where: {
          barbershopId: client.barbershopId,
          recipient: client.phone,
          type: 'REACTIVATION',
          createdAt: { gte: dayjs().subtract(30, 'day').toDate() },
        },
      });

      if (!alreadySent) {
        const message = `Olá ${client.name}! 👋 Sentimos sua falta na *${client.barbershop.name}*. Que tal agendar um horário? Acesse: ${this.config.get('APP_URL')}/${client.barbershop.slug}`;
        await this.logNotification({
          barbershopId: client.barbershopId,
          type: 'REACTIVATION',
          channel: 'WHATSAPP',
          recipient: client.phone,
          message,
        });
        await this.sendWhatsApp(client.phone, message);
      }
    }
  }

  private async send(appointment: any, type: string, message: string) {
    const phone = appointment.client?.phone;
    if (!phone) return;

    await this.logNotification({
      barbershopId: appointment.barbershopId,
      appointmentId: appointment.id,
      type: type as any,
      channel: 'WHATSAPP',
      recipient: phone,
      message,
    });

    await this.sendWhatsApp(phone, message);
  }

  private async sendWhatsApp(phone: string, message: string) {
    const enabled = this.config.get('WHATSAPP_ENABLED') === 'true';

    if (!enabled) {
      // Simula envio com log
      this.logger.log(`[WhatsApp SIMULADO] Para: ${phone}\n${message}\n${'─'.repeat(50)}`);
      return;
    }

    try {
      const apiUrl = this.config.get('WHATSAPP_API_URL');
      const token = this.config.get('WHATSAPP_API_TOKEN');
      const instance = this.config.get('WHATSAPP_INSTANCE');

      await axios.post(
        `${apiUrl}/message/sendText/${instance}`,
        { number: phone, text: message },
        { headers: { apikey: token } },
      );
    } catch (error) {
      this.logger.error(`Falha ao enviar WhatsApp para ${phone}: ${error.message}`);
    }
  }

  private buildMessage(type: string, appointment: any): string {
    const name = appointment.client?.name?.split(' ')[0] || 'Cliente';
    const shop = appointment.barbershop?.name || 'Barbearia';
    const service = appointment.service?.name || 'Serviço';
    const employee = appointment.employee?.name || 'Profissional';
    const date = dayjs(appointment.startAt).format('DD/MM/YYYY');
    const time = dayjs(appointment.startAt).format('HH:mm');
    const price = appointment.finalPrice?.toFixed(2).replace('.', ',');

    const messages: Record<string, string> = {
      CONFIRMATION: `✅ *Agendamento Confirmado!*\n\nOlá ${name}! Seu agendamento foi realizado com sucesso.\n\n📋 *Serviço:* ${service}\n👨 *Profissional:* ${employee}\n📅 *Data:* ${date}\n⏰ *Horário:* ${time}\n💰 *Valor:* R$ ${price}\n\nQualquer dúvida, entre em contato. Até logo! ✂️`,
      REMINDER_24H: `⏰ *Lembrete - Amanhã é seu dia!*\n\nOlá ${name}! Passando para lembrar que amanhã você tem um agendamento na *${shop}*.\n\n📋 ${service} com ${employee} às ${time}\n\nTe esperamos! ✂️`,
      REMINDER_1H: `⚡ *Em 1 hora é sua vez!*\n\nOlá ${name}! Em 1 hora você tem ${service} com ${employee} na *${shop}*.\n\nNos vemos em breve! ✂️`,
      CANCELLATION: `❌ *Agendamento Cancelado*\n\nOlá ${name}, seu agendamento de ${service} em ${date} às ${time} foi cancelado.\n\nPara reagendar, acesse nosso link. Até logo! 👋`,
      REVIEW_REQUEST: `⭐ *Como foi sua experiência?*\n\nOlá ${name}! Esperamos que tenha gostado do serviço na *${shop}*.\n\nSua avaliação é muito importante para nós! 🙏`,
      REACTIVATION: `👋 *Sentimos sua falta!*\n\nOlá ${name}! Faz um tempo que você não nos visita. Que tal agendar um horário na *${shop}*? ✂️`,
    };

    return messages[type] || '';
  }

  private async logNotification(data: {
    barbershopId: string;
    appointmentId?: string;
    type: any;
    channel: any;
    recipient: string;
    message: string;
  }) {
    await this.prisma.notificationLog.create({ data: { ...data, status: 'SENT', sentAt: new Date() } });
  }
}
