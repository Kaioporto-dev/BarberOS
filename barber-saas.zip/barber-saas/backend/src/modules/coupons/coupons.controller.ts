import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { CouponsService } from './coupons.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('coupons')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'coupons', version: '1' })
export class CouponsController {
  constructor(private readonly svc: CouponsService) {}

  @Get()        findAll(@CurrentUser() u: any) { return this.svc.findAll(u.barbershopId); }
  @Post()       create(@CurrentUser() u: any, @Body() dto: any) { return this.svc.create(u.barbershopId, dto); }
  @Post('validate') validateCoupon(@CurrentUser() u: any, @Body('code') code: string, @Body('price') price?: number) { return this.svc.validate(u.barbershopId, code, price); }
  @Patch(':id') update(@CurrentUser() u: any, @Param('id') id: string, @Body() dto: any) { return this.svc.update(u.barbershopId, id, dto); }
  @Delete(':id') @HttpCode(HttpStatus.NO_CONTENT) remove(@CurrentUser() u: any, @Param('id') id: string) { return this.svc.delete(u.barbershopId, id); }
}
