// BookingConfirmPage.tsx — Página de histórico do cliente
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, Calendar, Scissors, Clock, DollarSign, CheckCircle, XCircle } from 'lucide-react';
import dayjs from 'dayjs';
import { publicApi } from '../../services/api';
import clsx from 'clsx';

const statusLabels: Record<string, { label: string; color: string }> = {
  PENDING:   { label: 'Pendente',   color: 'text-yellow-600 bg-yellow-50' },
  CONFIRMED: { label: 'Confirmado', color: 'text-blue-600 bg-blue-50' },
  COMPLETED: { label: 'Concluído',  color: 'text-green-600 bg-green-50' },
  CANCELLED: { label: 'Cancelado',  color: 'text-red-600 bg-red-50' },
};

export default function BookingConfirmPage() {
  const { slug } = useParams<{ slug: string }>();
  const [phone, setPhone] = useState('');
  const [searched, setSearched] = useState('');

  const { data: shop } = useQuery({
    queryKey: ['public-shop', slug],
    queryFn: () => publicApi.getBarbershop(slug!),
    enabled: !!slug,
  });

  const { data: history, isLoading } = useQuery({
    queryKey: ['client-history', slug, searched],
    queryFn: () => publicApi.getClientHistory(slug!, searched),
    enabled: !!searched,
  });

  const accentColor = shop?.accentColor || '#e94560';

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-950">
      <div className="max-w-lg mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <Scissors className="w-10 h-10 mx-auto mb-3" style={{ color: accentColor }} />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Meus agendamentos</h1>
          <p className="text-gray-500 text-sm mt-1">{shop?.name}</p>
        </div>

        <div className="card p-6 mb-6">
          <label className="label">Digite seu telefone para ver seus agendamentos</label>
          <div className="flex gap-2">
            <input
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="input flex-1"
              placeholder="(11) 99999-9999"
              type="tel"
            />
            <button
              onClick={() => setSearched(phone)}
              disabled={!phone}
              className="btn-primary px-4"
              style={{ background: accentColor }}
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
        </div>

        {searched && (
          isLoading ? (
            <div className="text-center py-8 text-gray-400">Buscando...</div>
          ) : history?.items?.length === 0 ? (
            <div className="text-center py-8 card p-8">
              <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Nenhum agendamento encontrado para este número</p>
            </div>
          ) : (
            <div className="space-y-3">
              {history?.items?.map((apt: any) => {
                const st = statusLabels[apt.status] || { label: apt.status, color: '' };
                return (
                  <div key={apt.id} className="card p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="font-bold text-gray-900 dark:text-white">{apt.service?.name}</p>
                        <p className="text-sm text-gray-500">com {apt.employee?.name}</p>
                      </div>
                      <span className={clsx('text-xs font-semibold px-2.5 py-1 rounded-full', st.color)}>{st.label}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{dayjs(apt.startAt).format('DD/MM/YYYY')}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{dayjs(apt.startAt).format('HH:mm')}</span>
                      <span className="flex items-center gap-1 ml-auto font-bold" style={{ color: accentColor }}><DollarSign className="w-3.5 h-3.5" />R$ {apt.finalPrice?.toFixed(2)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        )}
      </div>
    </div>
  );
}
