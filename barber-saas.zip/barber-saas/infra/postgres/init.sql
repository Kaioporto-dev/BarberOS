-- BarberOS — PostgreSQL Init Script
-- Executed once when the container is first created

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable pg_trgm for full-text search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Timezone
SET timezone = 'America/Sao_Paulo';

-- Create indexes (Prisma will create the schema, this is for extras)
-- These will run after Prisma migrate deploy

\echo '✅ BarberOS PostgreSQL initialized'
