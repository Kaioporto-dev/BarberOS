export { default } from './AppointmentsPageImpl';

