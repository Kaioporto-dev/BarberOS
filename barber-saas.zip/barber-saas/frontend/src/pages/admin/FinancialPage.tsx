// ================================================
// FinancialPage.tsx
// ================================================
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DollarSign, TrendingUp, CreditCard, Banknote } from 'lucide-react';
import dayjs from 'dayjs';
import { reportsApi, paymentsApi } from '../../services/api';

const methodLabels: Record<string, string> = {
  CASH: 'Dinheiro', PIX: 'PIX', CREDIT_CARD: 'Crédito', DEBIT_CARD: 'Débito', STRIPE: 'Stripe', MERCADO_PAGO: 'Mercado Pago',
};
const methodColors: Record<string, string> = {
  CASH: '#22c55e', PIX: '#6366f1', CREDIT_CARD: '#f59e0b', DEBIT_CARD: '#06b6d4', STRIPE: '#8b5cf6', MERCADO_PAGO: '#3b82f6',
};

export default function FinancialPage() {
  const [date, setDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [period, setPeriod] = useState<'week' | 'month'>('month');

  const startDate = period === 'month'
    ? dayjs().startOf('month').format('YYYY-MM-DD')
    : dayjs().subtract(6, 'day').format('YYYY-MM-DD');

  const { data: cashFlow } = useQuery({ queryKey: ['cash-flow', date], queryFn: () => reportsApi.dailyCashFlow(date) });
  const { data: revenue } = useQuery({ queryKey: ['revenue', startDate], queryFn: () => reportsApi.revenue(startDate, dayjs().format('YYYY-MM-DD')) });
  const { data: payments } = useQuery({ queryKey: ['payments'], queryFn: () => paymentsApi.list({ limit: 20 }) });

  return (
    <div className="space-y-6">
      <div className="page-header flex-wrap gap-3">
        <h1 className="page-title">Financeiro</h1>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input w-auto py-2" />
      </div>

      {/* Cash Flow Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total do dia</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                R$ {cashFlow?.totalPaid?.toFixed(2) || '0,00'}
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>

        {cashFlow?.byMethod && Object.entries(cashFlow.byMethod).map(([method, total]: any) => (
          <div key={method} className="stat-card">
            <p className="text-sm text-gray-500">{methodLabels[method] || method}</p>
            <p className="text-xl font-bold mt-1" style={{ color: methodColors[method] }}>
              R$ {total?.toFixed(2)}
            </p>
          </div>
        ))}
      </div>

      {/* Period Revenue Chart */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">Faturamento por período</h2>
          <div className="flex rounded-xl border border-gray-200 dark:border-dark-600 overflow-hidden">
            {(['week', 'month'] as const).map(p => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 text-xs font-semibold transition-colors ${period === p ? 'bg-brand-600 text-white' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-dark-700'}`}
              >
                {p === 'week' ? '7 dias' : 'Mês'}
              </button>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={revenue || []}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
            <XAxis dataKey="date" tickFormatter={v => dayjs(v).format('DD/MM')} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <YAxis tickFormatter={v => `R$${v}`} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <Tooltip
              formatter={(v: number) => [`R$ ${v.toFixed(2)}`, 'Faturamento']}
              labelFormatter={l => dayjs(l).format('DD/MM/YYYY')}
              contentStyle={{ background: '#16162a', border: '1px solid #252542', borderRadius: '12px', fontSize: '12px' }}
            />
            <Bar dataKey="total" fill="#f9244d" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Recent Payments */}
      <div className="card">
        <div className="p-5 border-b border-gray-100 dark:border-dark-700">
          <h2 className="section-title">Pagamentos recentes</h2>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Serviço</th>
              <th>Forma</th>
              <th>Valor</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {payments?.items?.map((p: any) => (
              <tr key={p.id}>
                <td className="font-medium">{p.appointment?.client?.name || '—'}</td>
                <td className="text-gray-500">{p.appointment?.service?.name || '—'}</td>
                <td>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 dark:bg-dark-700 font-medium">
                    {methodLabels[p.method] || p.method}
                  </span>
                </td>
                <td className="font-bold text-brand-600 dark:text-brand-400">R$ {p.amount?.toFixed(2)}</td>
                <td>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${p.status === 'PAID' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : p.status === 'PENDING' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400' : 'bg-red-100 text-red-700'}`}>
                    {p.status === 'PAID' ? 'Pago' : p.status === 'PENDING' ? 'Pendente' : p.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
