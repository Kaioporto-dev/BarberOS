import { Controller, Get, Post, Param, Query, Body } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { BarbershopsService } from './barbershops.service';
import { AppointmentsService } from '../appointments/appointments.service';

@ApiTags('public')
@Controller({ path: 'public', version: '1' })
export class PublicController {
  constructor(
    private readonly svc: BarbershopsService,
    private readonly apts: AppointmentsService,
  ) {}

  @Get(':slug')
  getProfile(@Param('slug') slug: string) {
    return this.svc.getPublicProfile(slug);
  }

  @Get(':slug/slots')
  async getSlots(
    @Param('slug') slug: string,
    @Query('employeeId') employeeId: string,
    @Query('date') date: string,
    @Query('serviceId') serviceId: string,
  ) {
    const shop = await this.svc.getPublicProfile(slug);
    return this.apts.getAvailableSlots(shop.id, employeeId, date, serviceId);
  }

  @Post(':slug/book')
  async book(@Param('slug') slug: string, @Body() dto: any) {
    const shop = await this.svc.getPublicProfile(slug);
    return this.apts.create(shop.id, dto);
  }

  @Get(':slug/history')
  history(@Param('slug') slug: string, @Query('phone') phone: string) {
    return this.svc.getClientHistory(slug, phone);
  }
}
