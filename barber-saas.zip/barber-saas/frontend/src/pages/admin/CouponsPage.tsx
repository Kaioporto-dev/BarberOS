// CouponsPage.tsx
import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Tag, Trash2, Edit2, X, Loader2, Copy, Check } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import dayjs from 'dayjs';
import { couponsApi } from '../../services/api';
import clsx from 'clsx';

const schema = z.object({
  code: z.string().min(3).toUpperCase(),
  description: z.string().optional(),
  discountType: z.enum(['PERCENT', 'FIXED']),
  discountValue: z.coerce.number().min(0.01),
  maxUses: z.coerce.number().optional(),
  minValue: z.coerce.number().optional(),
  validUntil: z.string().optional(),
});
type FormData = z.infer<typeof schema>;

function CouponModal({ coupon, onClose, onSuccess }: any) {
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, watch, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      code: coupon?.code || '', description: coupon?.description || '',
      discountType: coupon?.discountType || 'PERCENT', discountValue: coupon?.discountValue || 10,
      maxUses: coupon?.maxUses || undefined, validUntil: coupon?.validUntil ? dayjs(coupon.validUntil).format('YYYY-MM-DD') : '',
    },
  });
  const discountType = watch('discountType');
  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      if (coupon) await couponsApi.update(coupon.id, data);
      else await couponsApi.create(data);
      toast.success(coupon ? 'Cupom atualizado!' : 'Cupom criado!');
      onSuccess();
    } catch (err: any) { toast.error(err.response?.data?.message || 'Erro'); }
    finally { setLoading(false); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-dark-700">
          <h2 className="section-title">{coupon ? 'Editar cupom' : 'Novo cupom'}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><label className="label">Código do cupom</label><input {...register('code')} className="input font-mono uppercase" placeholder="PRIMEIRAVISITA" />{errors.code && <p className="text-red-500 text-xs mt-1">Mínimo 3 caracteres</p>}</div>
            <div><label className="label">Tipo de desconto</label>
              <select {...register('discountType')} className="input">
                <option value="PERCENT">Percentual (%)</option>
                <option value="FIXED">Valor fixo (R$)</option>
              </select>
            </div>
            <div><label className="label">Valor</label><input {...register('discountValue')} type="number" step="0.01" className="input" /><p className="text-xs text-gray-400 mt-0.5">{discountType === 'PERCENT' ? 'Porcentagem de desconto' : 'Valor em reais'}</p></div>
            <div><label className="label">Máx. de usos</label><input {...register('maxUses')} type="number" className="input" placeholder="Ilimitado" /></div>
            <div><label className="label">Valor mínimo (R$)</label><input {...register('minValue')} type="number" step="0.01" className="input" placeholder="Sem mínimo" /></div>
            <div className="col-span-2"><label className="label">Válido até</label><input {...register('validUntil')} type="date" className="input" /></div>
            <div className="col-span-2"><label className="label">Descrição</label><input {...register('description')} className="input" placeholder="Desconto de boas-vindas" /></div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancelar</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Salvar'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function CouponsPage() {
  const [modal, setModal] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ['coupons'], queryFn: couponsApi.list });

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleDelete = async (c: any) => {
    if (!confirm(`Excluir cupom "${c.code}"?`)) return;
    try { await couponsApi.delete(c.id); toast.success('Excluído!'); qc.invalidateQueries({ queryKey: ['coupons'] }); } catch { toast.error('Erro'); }
  };

  const handleSuccess = () => { qc.invalidateQueries({ queryKey: ['coupons'] }); setModal(false); setSelected(null); };

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Cupons de Desconto</h1>
        <button className="btn-primary" onClick={() => { setSelected(null); setModal(true); }}><Plus className="w-4 h-4" />Novo cupom</button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? Array(3).fill(0).map((_, i) => <div key={i} className="card p-6 h-36 animate-pulse" />) :
          (data || []).map((c: any) => (
            <div key={c.id} className={clsx('card p-5 space-y-3 hover:shadow-lg transition-shadow', !c.isActive && 'opacity-50')}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-brand-50 dark:bg-brand-950/30 flex items-center justify-center"><Tag className="w-4 h-4 text-brand-600 dark:text-brand-400" /></div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-gray-900 dark:text-white">{c.code}</span>
                      <button onClick={() => handleCopy(c.code)} className="p-0.5 text-gray-400 hover:text-brand-500">
                        {copied === c.code ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <p className="text-xs text-gray-400">{c.description}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => { setSelected(c); setModal(true); }} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30"><Edit2 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => handleDelete(c)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-gray-100 dark:border-dark-700">
                <span className="text-lg font-bold text-brand-600 dark:text-brand-400">
                  {c.discountType === 'PERCENT' ? `${c.discountValue}% OFF` : `R$ ${c.discountValue} OFF`}
                </span>
                <div className="text-right text-xs text-gray-400">
                  <p>{c.usedCount}/{c.maxUses || '∞'} usos</p>
                  {c.validUntil && <p>Até {dayjs(c.validUntil).format('DD/MM/YYYY')}</p>}
                </div>
              </div>
            </div>
          ))}
      </div>

      {modal && <CouponModal coupon={selected} onClose={() => { setModal(false); setSelected(null); }} onSuccess={handleSuccess} />}
    </div>
  );
}
