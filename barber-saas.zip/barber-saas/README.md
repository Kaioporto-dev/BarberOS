# BarberOS — SaaS de Gestão para Barbearias

> Sistema completo multi-tenant de agendamento e gestão para barbearias.

## Stack Tecnológica

| Camada      | Tecnologia                         |
|-------------|-----------------------------------|
| Backend     | Node.js + NestJS                  |
| Banco       | PostgreSQL + Prisma ORM           |
| Frontend    | React 18 + Tailwind CSS           |
| Auth        | JWT (access + refresh tokens)     |
| Pagamentos  | Stripe / Mercado Pago (estrutura) |
| Mensageria  | WhatsApp API (simulada via logs)  |
| Deploy      | Docker + Docker Compose           |

---

## Pré-requisitos

- Docker >= 24.x
- Docker Compose >= 2.x
- Node.js >= 20.x (para desenvolvimento local)

---

## Início rápido (Docker)

```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/barber-saas.git
cd barber-saas

# 2. Copie os arquivos de variáveis de ambiente
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env

# 3. Edite as variáveis necessárias
nano backend/.env

# 4. Suba toda a stack
docker-compose up -d

# 5. Execute as migrations do banco
docker-compose exec backend npx prisma migrate deploy

# 6. (Opcional) Popule com dados de exemplo
docker-compose exec backend npx prisma db seed
```

Acesse:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:4000
- **Documentação API**: http://localhost:4000/api/docs
- **Prisma Studio**: http://localhost:5555

---

## Desenvolvimento local

### Backend

```bash
cd backend
npm install
cp .env.example .env
# Configure o banco PostgreSQL local no .env

npx prisma migrate dev
npx prisma generate
npm run start:dev
```

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

---

## Estrutura do Projeto

```
barber-saas/
├── backend/
│   ├── src/
│   │   ├── modules/
│   │   │   ├── auth/           # JWT auth, refresh tokens
│   │   │   ├── barbershops/    # Multi-tenant core
│   │   │   ├── appointments/   # Agendamentos
│   │   │   ├── clients/        # CRM de clientes
│   │   │   ├── services/       # Serviços oferecidos
│   │   │   ├── employees/      # Barbeiros/funcionários
│   │   │   ├── payments/       # Financeiro
│   │   │   ├── subscriptions/  # Planos mensais
│   │   │   ├── reviews/        # Avaliações
│   │   │   ├── coupons/        # Cupons de desconto
│   │   │   └── notifications/  # WhatsApp/SMS
│   │   ├── common/
│   │   │   ├── guards/         # Auth, Tenant, Roles
│   │   │   ├── decorators/     # @CurrentUser, @Tenant
│   │   │   ├── filters/        # Exception filters
│   │   │   └── pipes/          # Validation pipes
│   │   └── prisma/             # Schema + migrations
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── admin/          # Dashboard, agenda, CRM...
│   │   │   ├── client/         # Booking público
│   │   │   └── auth/           # Login, registro
│   │   ├── components/         # UI reutilizável
│   │   ├── hooks/              # Custom React hooks
│   │   ├── services/           # Chamadas API
│   │   └── store/              # Estado global (Zustand)
│   └── Dockerfile
├── infra/
│   ├── nginx/                  # Reverse proxy config
│   └── postgres/               # Init scripts
├── docker-compose.yml
└── README.md
```

---

## Fluxos principais

### Agendamento público
1. Cliente acessa `/{barbershop-slug}`
2. Seleciona serviço → profissional → horário
3. Informa nome + telefone
4. Confirma agendamento → recebe confirmação (WhatsApp simulado)

### Área administrativa
1. Dono faz login em `/admin/login`
2. Acessa dashboard com métricas em tempo real
3. Gerencia agenda, clientes, financeiro e equipe

---

## Multi-tenancy

Cada barbearia é isolada por `barbershopId` em todas as queries.  
O middleware `TenantGuard` injeta automaticamente o contexto do tenant via:
- JWT claim `barbershopId`
- Header `X-Tenant-ID` (para API pública)
- Slug na URL pública

---

## Segurança

- JWT com access token (15min) + refresh token (7d)
- Bcrypt para senhas (12 rounds)
- Validação com class-validator em todos DTOs
- Rate limiting por IP e por tenant
- CORS configurado por ambiente
- Isolamento total de dados por tenant

---

## Licença

MIT — use livremente em seus projetos comerciais.
