import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { EmployeesService } from './employees.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('employees')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'employees', version: '1' })
export class EmployeesController {
  constructor(private readonly svc: EmployeesService) {}

  @Get()        findAll(@CurrentUser() u: any, @Query() q: any) { return this.svc.findAll(u.barbershopId, q); }
  @Get(':id')   findOne(@CurrentUser() u: any, @Param('id') id: string) { return this.svc.findOne(u.barbershopId, id); }
  @Post()       create(@CurrentUser() u: any, @Body() dto: any) { return this.svc.create(u.barbershopId, dto); }
  @Patch(':id') update(@CurrentUser() u: any, @Param('id') id: string, @Body() dto: any) { return this.svc.update(u.barbershopId, id, dto); }
  @Delete(':id') @HttpCode(HttpStatus.NO_CONTENT) remove(@CurrentUser() u: any, @Param('id') id: string) { return this.svc.delete(u.barbershopId, id); }
}
