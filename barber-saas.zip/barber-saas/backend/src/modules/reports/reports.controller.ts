import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('reports')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'reports', version: '1' })
export class ReportsController {
  constructor(private readonly svc: ReportsService) {}

  @Get('dashboard')     dashboard(@CurrentUser() u: any) { return this.svc.getDashboard(u.barbershopId); }
  @Get('revenue')       revenue(@CurrentUser() u: any, @Query('startDate') s: string, @Query('endDate') e: string) { return this.svc.getRevenueByPeriod(u.barbershopId, s, e); }
  @Get('top-employees') topEmps(@CurrentUser() u: any, @Query() q: any) { return this.svc.getTopEmployees(u.barbershopId, q.startDate, q.endDate); }
  @Get('top-services')  topSvcs(@CurrentUser() u: any, @Query() q: any) { return this.svc.getTopServices(u.barbershopId, q.startDate, q.endDate); }
  @Get('best-days')     bestDays(@CurrentUser() u: any) { return this.svc.getBestDays(u.barbershopId); }
  @Get('average-ticket') avgTicket(@CurrentUser() u: any) { return this.svc.getAverageTicket(u.barbershopId); }
  @Get('cash-flow')     cashFlow(@CurrentUser() u: any, @Query('date') date: string) { return this.svc.getDailyCashFlow(u.barbershopId, date); }
  @Get('inactive-clients') inactive(@CurrentUser() u: any, @Query('days') days: number) { return this.svc.getInactiveClients(u.barbershopId, days); }
}
