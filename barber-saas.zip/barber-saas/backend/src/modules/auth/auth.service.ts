import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
    private config: ConfigService,
  ) {}

  async register(dto: RegisterDto) {
    const exists = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (exists) throw new ConflictException('E-mail já cadastrado');

    const hashedPassword = await bcrypt.hash(dto.password, this.config.get('BCRYPT_ROUNDS', 12));

    // Cria barbearia e usuário owner em transação
    const result = await this.prisma.$transaction(async (tx) => {
      const barbershop = await tx.barbershop.create({
        data: {
          name: dto.barbershopName,
          slug: await this.generateSlug(dto.barbershopName, tx),
          phone: dto.phone,
        },
      });

      const user = await tx.user.create({
        data: {
          email: dto.email,
          password: hashedPassword,
          name: dto.name,
          phone: dto.phone,
          role: 'OWNER',
          barbershopId: barbershop.id,
        },
      });

      // Cria horários padrão
      const days = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
      await tx.workingHours.createMany({
        data: days.map((day) => ({
          barbershopId: barbershop.id,
          dayOfWeek: day as any,
          isOpen: true,
          openTime: '09:00',
          closeTime: '19:00',
        })),
      });

      // Cria subscription free trial
      await tx.barbershopSubscription.create({
        data: {
          barbershopId: barbershop.id,
          plan: 'FREE',
          status: 'TRIALING',
          trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 dias
        },
      });

      return { user, barbershop };
    });

    const tokens = await this.generateTokens(result.user.id, result.user.role, result.barbershop.id);
    return { user: this.sanitizeUser(result.user), barbershop: result.barbershop, ...tokens };
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: { barbershop: true },
    });

    if (!user || !await bcrypt.compare(dto.password, user.password)) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    if (!user.isActive) throw new UnauthorizedException('Conta desativada');

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const tokens = await this.generateTokens(user.id, user.role, user.barbershopId);
    return { user: this.sanitizeUser(user), barbershop: user.barbershop, ...tokens };
  }

  async refresh(token: string) {
    const stored = await this.prisma.refreshToken.findUnique({
      where: { token },
      include: { user: { include: { barbershop: true } } },
    });

    if (!stored || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Refresh token inválido ou expirado');
    }

    // Rotaciona o refresh token
    await this.prisma.refreshToken.delete({ where: { token } });
    const tokens = await this.generateTokens(stored.user.id, stored.user.role, stored.user.barbershopId);
    return { user: this.sanitizeUser(stored.user), ...tokens };
  }

  async logout(userId: string, refreshToken?: string) {
    if (refreshToken) {
      await this.prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
    } else {
      // Revoga todos os refresh tokens do usuário
      await this.prisma.refreshToken.deleteMany({ where: { userId } });
    }
  }

  async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (user && await bcrypt.compare(password, user.password)) return user;
    return null;
  }

  private async generateTokens(userId: string, role: string, barbershopId: string | null) {
    const payload = { sub: userId, role, barbershopId };

    const accessToken = this.jwt.sign(payload, {
      secret: this.config.get('JWT_ACCESS_SECRET'),
      expiresIn: this.config.get('JWT_ACCESS_EXPIRES_IN', '15m'),
    });

    const refreshToken = this.jwt.sign(payload, {
      secret: this.config.get('JWT_REFRESH_SECRET'),
      expiresIn: this.config.get('JWT_REFRESH_EXPIRES_IN', '7d'),
    });

    const expiresIn = 7 * 24 * 60 * 60 * 1000; // 7d
    await this.prisma.refreshToken.create({
      data: {
        userId,
        token: refreshToken,
        expiresAt: new Date(Date.now() + expiresIn),
      },
    });

    return { accessToken, refreshToken };
  }

  private async generateSlug(name: string, tx: any): Promise<string> {
    const base = name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    let slug = base;
    let counter = 1;
    while (await tx.barbershop.findUnique({ where: { slug } })) {
      slug = `${base}-${counter++}`;
    }
    return slug;
  }

  private sanitizeUser(user: any) {
    const { password, twoFactorSecret, ...rest } = user;
    return rest;
  }
}
