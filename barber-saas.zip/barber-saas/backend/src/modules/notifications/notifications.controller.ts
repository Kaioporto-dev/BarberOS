import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { PrismaService } from '../prisma/prisma.service';

@ApiTags('notifications')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'notifications', version: '1' })
export class NotificationsController {
  constructor(private prisma: PrismaService) {}

  @Get()
  getLogs(@CurrentUser() u: any, @Query() q: any) {
    return this.prisma.notificationLog.findMany({
      where: { barbershopId: u.barbershopId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }
}
