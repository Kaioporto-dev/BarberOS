import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff, Loader2, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { authApi } from '../../services/api';
import { useAuthStore } from '../../store/auth.store';

const schema = z.object({
  name: z.string().min(2, 'Nome obrigatório'),
  email: z.string().email('E-mail inválido'),
  password: z.string().min(8, 'Mínimo 8 caracteres'),
  phone: z.string().optional(),
  barbershopName: z.string().min(2, 'Nome da barbearia obrigatório'),
});

type FormData = z.infer<typeof schema>;

const benefits = [
  'Agendamento online 24/7',
  'Gestão de clientes (CRM)',
  'Relatórios financeiros',
  'Notificações automáticas via WhatsApp',
  '14 dias grátis, sem cartão',
];

export default function RegisterPage() {
  const [showPw, setShowPw] = useState(false);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      const result = await authApi.register(data);
      setAuth(result);
      toast.success('Barbearia criada com sucesso! 🎉');
      navigate('/admin/dashboard');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Erro ao criar conta');
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-1">Crie sua conta grátis</h2>
      <p className="text-sm text-gray-400 mb-6">14 dias de trial, sem precisar de cartão</p>

      {/* Benefits */}
      <div className="mb-6 space-y-1.5">
        {benefits.map(b => (
          <div key={b} className="flex items-center gap-2 text-xs text-gray-400">
            <CheckCircle className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
            {b}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <label className="label text-gray-300">Nome da barbearia</label>
            <input {...register('barbershopName')} className="input bg-dark-700 border-dark-500 text-white" placeholder="Barbearia do João" />
            {errors.barbershopName && <p className="text-red-400 text-xs mt-1">{errors.barbershopName.message}</p>}
          </div>
          <div>
            <label className="label text-gray-300">Seu nome</label>
            <input {...register('name')} className="input bg-dark-700 border-dark-500 text-white" placeholder="João Silva" />
            {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name.message}</p>}
          </div>
          <div>
            <label className="label text-gray-300">Telefone</label>
            <input {...register('phone')} className="input bg-dark-700 border-dark-500 text-white" placeholder="(11) 99999-9999" />
          </div>
        </div>
        <div>
          <label className="label text-gray-300">E-mail</label>
          <input {...register('email')} type="email" className="input bg-dark-700 border-dark-500 text-white" placeholder="seu@email.com" />
          {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email.message}</p>}
        </div>
        <div>
          <label className="label text-gray-300">Senha</label>
          <div className="relative">
            <input {...register('password')} type={showPw ? 'text' : 'password'} className="input bg-dark-700 border-dark-500 text-white pr-12" placeholder="Mínimo 8 caracteres" />
            <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200" onClick={() => setShowPw(!showPw)}>
              {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password.message}</p>}
        </div>

        <button type="submit" disabled={isSubmitting} className="btn-primary w-full justify-center py-3 mt-2">
          {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Criar minha barbearia'}
        </button>
      </form>

      <p className="text-center text-sm text-gray-500 mt-4">
        Já tem conta?{' '}
        <Link to="/admin/login" className="text-brand-400 hover:text-brand-300 font-medium">Entrar</Link>
      </p>
    </div>
  );
}
