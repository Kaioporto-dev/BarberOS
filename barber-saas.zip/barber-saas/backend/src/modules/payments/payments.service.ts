import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import * as dayjs from 'dayjs';

@Injectable()
export class PaymentsService {
  constructor(private prisma: PrismaService) {}

  async findAll(barbershopId: string, { startDate, endDate, page = 1, limit = 50 }: any = {}) {
    const where: any = { barbershopId };
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = dayjs(endDate).endOf('day').toDate();
    }
    const [total, items] = await Promise.all([
      this.prisma.payment.count({ where }),
      this.prisma.payment.findMany({
        where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: +limit,
        include: { appointment: { include: { client: true, service: true, employee: true } } },
      }),
    ]);
    return { total, page: +page, limit: +limit, items };
  }

  async create(barbershopId: string, dto: any) {
    const apt = await this.prisma.appointment.findFirst({ where: { id: dto.appointmentId, barbershopId }, include: { service: true, employee: true } });
    if (!apt) throw new NotFoundException('Agendamento não encontrado');
    const commission = (apt.finalPrice * (apt.employee as any)?.commission || 40) / 100;
    const payment = await this.prisma.payment.create({
      data: { ...dto, barbershopId, amount: apt.finalPrice, status: 'PAID', paidAt: new Date(), employeeCommission: commission },
    });
    if (apt.employeeId) {
      await this.prisma.employeePayment.create({ data: { employeeId: apt.employeeId, paymentId: payment.id, amount: commission } });
    }
    await this.prisma.appointment.update({ where: { id: dto.appointmentId }, data: { status: 'COMPLETED', completedAt: new Date() } });
    return payment;
  }

  async update(barbershopId: string, id: string, dto: any) {
    const p = await this.prisma.payment.findFirst({ where: { id, barbershopId } });
    if (!p) throw new NotFoundException('Pagamento não encontrado');
    return this.prisma.payment.update({ where: { id }, data: { ...dto, paidAt: dto.status === 'PAID' ? new Date() : p.paidAt } });
  }
}
