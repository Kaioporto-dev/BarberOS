import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Phone, Mail, Star, Calendar, DollarSign, ChevronRight, X, Loader2, Edit2, Trash2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import dayjs from 'dayjs';
import toast from 'react-hot-toast';
import { clientsApi } from '../../services/api';
import clsx from 'clsx';

const schema = z.object({
  name: z.string().min(2, 'Nome obrigatório'),
  phone: z.string().min(10, 'Telefone inválido'),
  email: z.string().email('E-mail inválido').optional().or(z.literal('')),
  birthDate: z.string().optional(),
  notes: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

function ClientModal({ client, onClose, onSuccess }: { client?: any; onClose: () => void; onSuccess: () => void }) {
  const isEditing = !!client;
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: client?.name || '',
      phone: client?.phone || '',
      email: client?.email || '',
      notes: client?.notes || '',
      birthDate: client?.birthDate ? dayjs(client.birthDate).format('YYYY-MM-DD') : '',
    },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      if (isEditing) await clientsApi.update(client.id, data);
      else await clientsApi.create(data);
      toast.success(isEditing ? 'Cliente atualizado!' : 'Cliente cadastrado!');
      onSuccess();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Erro ao salvar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-dark-700">
          <h2 className="section-title">{isEditing ? 'Editar cliente' : 'Novo cliente'}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div>
            <label className="label">Nome completo</label>
            <input {...register('name')} className="input" placeholder="João Silva" />
            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Telefone / WhatsApp</label>
              <input {...register('phone')} className="input" placeholder="(11) 99999-9999" />
              {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone.message}</p>}
            </div>
            <div>
              <label className="label">E-mail</label>
              <input {...register('email')} type="email" className="input" placeholder="joao@email.com" />
            </div>
          </div>
          <div>
            <label className="label">Data de nascimento</label>
            <input {...register('birthDate')} type="date" className="input" />
          </div>
          <div>
            <label className="label">Observações</label>
            <textarea {...register('notes')} rows={3} className="input resize-none" placeholder="Preferências, alergias..." />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancelar</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ClientDetailModal({ client, onClose }: { client: any; onClose: () => void }) {
  const { data: history } = useQuery({
    queryKey: ['client-history', client.id],
    queryFn: () => clientsApi.getHistory(client.id),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-lg max-h-[85vh] overflow-y-auto animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-dark-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-bold">
              {client.name?.[0]}
            </div>
            <div>
              <h2 className="section-title leading-tight">{client.name}</h2>
              <p className="text-xs text-gray-500">{client.phone}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-400"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: Calendar, label: 'Visitas', value: client.totalVisits },
              { icon: DollarSign, label: 'Total gasto', value: `R$ ${client.totalSpent?.toFixed(2) || '0,00'}` },
              { icon: Star, label: 'Ticket médio', value: `R$ ${client.averageTicket?.toFixed(2) || '0,00'}` },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="bg-gray-50 dark:bg-dark-700/50 rounded-xl p-3 text-center">
                <Icon className="w-4 h-4 text-brand-500 mx-auto mb-1" />
                <p className="text-xs text-gray-500 dark:text-gray-400">{label}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-white">{value}</p>
              </div>
            ))}
          </div>

          {/* Info */}
          {client.notes && (
            <div>
              <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Observações</p>
              <p className="text-sm text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-dark-700/50 rounded-xl p-3">{client.notes}</p>
            </div>
          )}

          {/* Last visit */}
          {client.lastVisitAt && (
            <p className="text-xs text-gray-400">
              Última visita: {dayjs(client.lastVisitAt).format('DD/MM/YYYY')}
            </p>
          )}

          {/* History */}
          <div>
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">Histórico de serviços</p>
            {history?.items?.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-4">Nenhum histórico ainda</p>
            )}
            <div className="space-y-2">
              {history?.items?.slice(0, 10).map((apt: any) => (
                <div key={apt.id} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-dark-700/50 rounded-xl">
                  <div className="w-1 h-8 rounded-full bg-brand-500 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">{apt.service?.name}</p>
                    <p className="text-xs text-gray-400">{apt.employee?.name} · {dayjs(apt.startAt).format('DD/MM/YYYY HH:mm')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-brand-600 dark:text-brand-400">R$ {apt.finalPrice?.toFixed(2)}</p>
                    <span className={clsx('text-xs px-1.5 py-0.5 rounded font-medium',
                      apt.status === 'COMPLETED' ? 'text-green-600 bg-green-50 dark:bg-green-900/20' : 'text-gray-500'
                    )}>{apt.status === 'COMPLETED' ? 'Concluído' : apt.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ClientsPage() {
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<'create' | 'edit' | 'detail' | null>(null);
  const [selected, setSelected] = useState<any>(null);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['clients', search],
    queryFn: () => clientsApi.list({ search, limit: 50 }),
    keepPreviousData: true,
  } as any);

  const handleSuccess = () => {
    qc.invalidateQueries({ queryKey: ['clients'] });
    setModal(null);
    setSelected(null);
  };

  const handleDelete = async (client: any) => {
    if (!confirm(`Excluir cliente "${client.name}"?`)) return;
    try {
      await clientsApi.delete(client.id);
      toast.success('Cliente excluído');
      qc.invalidateQueries({ queryKey: ['clients'] });
    } catch {
      toast.error('Erro ao excluir');
    }
  };

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Clientes</h1>
        <button className="btn-primary" onClick={() => { setSelected(null); setModal('create'); }}>
          <Plus className="w-4 h-4" /> Novo cliente
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          className="input pl-10"
          placeholder="Buscar por nome ou telefone..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Contato</th>
              <th className="hidden md:table-cell">Visitas</th>
              <th className="hidden lg:table-cell">Total gasto</th>
              <th className="hidden lg:table-cell">Última visita</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array(6).fill(0).map((_, i) => (
                <tr key={i}>
                  {Array(5).fill(0).map((_, j) => (
                    <td key={j}><div className="h-4 bg-gray-100 dark:bg-dark-700 rounded animate-pulse" /></td>
                  ))}
                </tr>
              ))
            ) : data?.items?.map((client: any) => (
              <tr key={client.id} className="cursor-pointer" onClick={() => { setSelected(client); setModal('detail'); }}>
                <td>
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {client.name?.[0]}
                    </div>
                    <span className="font-semibold text-gray-900 dark:text-white">{client.name}</span>
                  </div>
                </td>
                <td>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 text-xs">
                      <Phone className="w-3 h-3 text-gray-400" />
                      {client.phone}
                    </div>
                    {client.email && (
                      <div className="flex items-center gap-1.5 text-xs text-gray-400">
                        <Mail className="w-3 h-3" />
                        {client.email}
                      </div>
                    )}
                  </div>
                </td>
                <td className="hidden md:table-cell">
                  <span className="font-semibold">{client.totalVisits}</span>
                </td>
                <td className="hidden lg:table-cell">
                  <span className="font-semibold text-brand-600 dark:text-brand-400">
                    R$ {client.totalSpent?.toFixed(2) || '0,00'}
                  </span>
                </td>
                <td className="hidden lg:table-cell text-gray-400 text-sm">
                  {client.lastVisitAt ? dayjs(client.lastVisitAt).format('DD/MM/YYYY') : 'Nunca'}
                </td>
                <td onClick={e => e.stopPropagation()}>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => { setSelected(client); setModal('edit'); }}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(client)}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {!isLoading && data?.items?.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">Nenhum cliente encontrado</p>
          </div>
        )}
      </div>

      {/* Modals */}
      {(modal === 'create' || modal === 'edit') && (
        <ClientModal
          client={modal === 'edit' ? selected : undefined}
          onClose={() => { setModal(null); setSelected(null); }}
          onSuccess={handleSuccess}
        />
      )}
      {modal === 'detail' && selected && (
        <ClientDetailModal client={selected} onClose={() => { setModal(null); setSelected(null); }} />
      )}
    </div>
  );
}
