import { useQuery } from '@tanstack/react-query';
import {
  TrendingUp, TrendingDown, Calendar, Users, DollarSign,
  Clock, CheckCircle, XCircle, Scissors, Star, ArrowRight,
  Activity,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import { reportsApi, appointmentsApi } from '../../services/api';
import { useAuthStore } from '../../store/auth.store';
import dayjs from 'dayjs';
import clsx from 'clsx';

const COLORS = ['#f9244d', '#6366f1', '#22c55e', '#f59e0b', '#06b6d4'];

function StatCard({
  icon: Icon, label, value, sub, trend, color = 'brand',
}: {
  icon: any; label: string; value: string | number; sub?: string;
  trend?: number; color?: string;
}) {
  const colorMap: Record<string, string> = {
    brand: 'from-brand-500 to-brand-700',
    blue: 'from-blue-500 to-blue-700',
    green: 'from-emerald-500 to-emerald-700',
    purple: 'from-violet-500 to-violet-700',
    amber: 'from-amber-500 to-amber-700',
  };

  return (
    <div className="stat-card animate-slide-up">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{label}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
          {sub && <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">{sub}</p>}
        </div>
        <div className={clsx(
          'w-11 h-11 rounded-xl bg-gradient-to-br flex items-center justify-center shadow-sm flex-shrink-0',
          colorMap[color]
        )}>
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>

      {trend !== undefined && (
        <div className={clsx(
          'flex items-center gap-1 text-xs font-semibold mt-1',
          trend >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500 dark:text-red-400'
        )}>
          {trend >= 0
            ? <TrendingUp className="w-3.5 h-3.5" />
            : <TrendingDown className="w-3.5 h-3.5" />}
          {Math.abs(trend)}% vs mês anterior
        </div>
      )}
    </div>
  );
}

function formatCurrency(v: number) {
  return `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

const statusConfig: Record<string, { label: string; cls: string }> = {
  PENDING:     { label: 'Pendente',     cls: 'status-pending' },
  CONFIRMED:   { label: 'Confirmado',   cls: 'status-confirmed' },
  COMPLETED:   { label: 'Concluído',    cls: 'status-completed' },
  CANCELLED:   { label: 'Cancelado',    cls: 'status-cancelled' },
  IN_PROGRESS: { label: 'Em andamento', cls: 'status-in_progress' },
  NO_SHOW:     { label: 'Não compareceu', cls: 'status-no_show' },
};

export default function DashboardPage() {
  const { barbershop } = useAuthStore();

  const { data: dashboard, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: reportsApi.dashboard,
    refetchInterval: 60000,
  });

  const { data: todayApts } = useQuery({
    queryKey: ['appointments', 'today'],
    queryFn: () => appointmentsApi.list({ date: dayjs().format('YYYY-MM-DD'), limit: 10 }),
  });

  const { data: revenueData } = useQuery({
    queryKey: ['revenue', 'week'],
    queryFn: () => reportsApi.revenue(
      dayjs().subtract(6, 'day').format('YYYY-MM-DD'),
      dayjs().format('YYYY-MM-DD')
    ),
  });

  const { data: topServices } = useQuery({
    queryKey: ['top-services'],
    queryFn: () => reportsApi.topServices({
      startDate: dayjs().startOf('month').format('YYYY-MM-DD'),
      endDate: dayjs().format('YYYY-MM-DD'),
    }),
  });

  const { data: topEmployees } = useQuery({
    queryKey: ['top-employees'],
    queryFn: reportsApi.topEmployees,
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Array(4).fill(0).map((_, i) => (
          <div key={i} className="stat-card animate-pulse">
            <div className="h-4 bg-gray-200 dark:bg-dark-600 rounded w-24 mb-3" />
            <div className="h-7 bg-gray-200 dark:bg-dark-600 rounded w-16" />
          </div>
        ))}
      </div>
    );
  }

  const d = dashboard;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="page-title">
          Bom dia! 👋
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
          {dayjs().format('dddd, D [de] MMMM [de] YYYY')} · {barbershop?.name}
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={DollarSign}
          label="Faturamento hoje"
          value={formatCurrency(d?.today?.revenue || 0)}
          sub={`R$ ${(d?.month?.revenue || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 })} no mês`}
          trend={d?.month?.revenueGrowth}
          color="brand"
        />
        <StatCard
          icon={Calendar}
          label="Agendamentos hoje"
          value={d?.today?.appointments || 0}
          sub={`${d?.month?.appointments || 0} no mês`}
          trend={d?.month?.appointmentGrowth}
          color="blue"
        />
        <StatCard
          icon={Clock}
          label="Pendentes hoje"
          value={d?.today?.pending || 0}
          sub="Aguardando confirmação"
          color="amber"
        />
        <StatCard
          icon={Users}
          label="Novos clientes"
          value={d?.month?.newClients || 0}
          sub="Este mês"
          color="green"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Revenue Chart */}
        <div className="card p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Faturamento (7 dias)</h2>
            <span className="text-xs text-gray-400 bg-gray-100 dark:bg-dark-700 px-2 py-1 rounded-lg">
              Últimos 7 dias
            </span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={revenueData || []}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f9244d" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f9244d" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis
                dataKey="date"
                tickFormatter={(v) => dayjs(v).format('DD/MM')}
                tick={{ fontSize: 11, fill: '#9ca3af' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`}
                tick={{ fontSize: 11, fill: '#9ca3af' }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                formatter={(v: number) => [`R$ ${v.toFixed(2)}`, 'Faturamento']}
                labelFormatter={(l) => dayjs(l).format('DD/MM/YYYY')}
                contentStyle={{
                  background: '#16162a',
                  border: '1px solid #252542',
                  borderRadius: '12px',
                  fontSize: '12px',
                }}
              />
              <Area
                type="monotone"
                dataKey="total"
                stroke="#f9244d"
                strokeWidth={2}
                fill="url(#colorRevenue)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Top Services Pie */}
        <div className="card p-6">
          <h2 className="section-title mb-4">Serviços populares</h2>
          {topServices?.length ? (
            <>
              <ResponsiveContainer width="100%" height={150}>
                <PieChart>
                  <Pie
                    data={topServices.slice(0, 5)}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={65}
                    paddingAngle={2}
                    dataKey="count"
                    nameKey="service.name"
                  >
                    {topServices.slice(0, 5).map((_: any, i: number) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(v: number, _: any, props: any) => [v, props.payload.service?.name]}
                    contentStyle={{ background: '#16162a', border: '1px solid #252542', borderRadius: '12px', fontSize: '12px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 mt-2">
                {topServices.slice(0, 5).map((s: any, i: number) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <span
                      className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                      style={{ background: COLORS[i % COLORS.length] }}
                    />
                    <span className="text-gray-600 dark:text-gray-400 truncate flex-1">{s.service?.name}</span>
                    <span className="font-semibold text-gray-900 dark:text-white">{s.count}x</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="text-sm text-gray-400 text-center py-8">Nenhum dado ainda</p>
          )}
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Today's appointments */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Agenda de hoje</h2>
            <a href="/admin/calendar" className="text-xs text-brand-600 dark:text-brand-400 flex items-center gap-1 hover:underline">
              Ver tudo <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {todayApts?.items?.length === 0 && (
            <div className="text-center py-8">
              <Calendar className="w-10 h-10 text-gray-300 dark:text-dark-600 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Nenhum agendamento hoje</p>
            </div>
          )}

          <div className="space-y-2">
            {todayApts?.items?.slice(0, 6).map((apt: any) => {
              const st = statusConfig[apt.status] || { label: apt.status, cls: '' };
              return (
                <div key={apt.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-dark-700/50 transition-colors">
                  <div className="text-center w-12 flex-shrink-0">
                    <p className="text-sm font-bold text-gray-900 dark:text-white">
                      {dayjs(apt.startAt).format('HH:mm')}
                    </p>
                    <p className="text-xs text-gray-400">{apt.service?.duration}min</p>
                  </div>
                  <div className="w-px h-8 bg-gray-200 dark:bg-dark-600" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">{apt.client?.name}</p>
                    <p className="text-xs text-gray-400 truncate">{apt.service?.name} · {apt.employee?.name}</p>
                  </div>
                  <span className={clsx('status-badge', st.cls)}>{st.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Employees */}
        <div className="card p-6">
          <h2 className="section-title mb-4">Ranking profissionais</h2>
          {topEmployees?.length ? (
            <div className="space-y-3">
              {topEmployees.slice(0, 5).map((e: any, i: number) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-gray-100 dark:bg-dark-700 flex items-center justify-center text-xs font-bold text-gray-600 dark:text-gray-400 flex-shrink-0">
                    {i + 1}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {e.employee?.name?.[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-semibold text-gray-800 dark:text-gray-200 truncate">{e.employee?.name}</p>
                      <p className="text-sm font-bold text-brand-600 dark:text-brand-400 ml-2 flex-shrink-0">
                        {formatCurrency(e.total)}
                      </p>
                    </div>
                    <div className="h-1.5 bg-gray-100 dark:bg-dark-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-brand-500 to-brand-600 rounded-full"
                        style={{ width: `${Math.min(100, (e.total / (topEmployees[0]?.total || 1)) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400 text-center py-8">Sem dados de faturamento</p>
          )}
        </div>
      </div>
    </div>
  );
}
