import { useQuery } from '@tanstack/react-query';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar,
} from 'recharts';
import { TrendingUp, Users, Scissors, Star, Activity } from 'lucide-react';
import { reportsApi } from '../../services/api';

export default function ReportsPage() {
  const { data: bestDays } = useQuery({ queryKey: ['best-days'], queryFn: reportsApi.bestDays });
  const { data: topEmployees } = useQuery({ queryKey: ['top-employees-report'], queryFn: reportsApi.topEmployees });
  const { data: topServices } = useQuery({ queryKey: ['top-services-report'], queryFn: reportsApi.topServices });
  const { data: avgTicket } = useQuery({ queryKey: ['avg-ticket'], queryFn: reportsApi.averageTicket });
  const { data: inactive } = useQuery({ queryKey: ['inactive'], queryFn: () => reportsApi.inactiveClients() });

  return (
    <div className="space-y-6">
      <h1 className="page-title">Relatórios & Inteligência</h1>

      {/* KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Activity, label: 'Ticket médio', value: `R$ ${avgTicket?.average?.toFixed(2) || '0,00'}`, color: 'from-brand-500 to-brand-700' },
          { icon: TrendingUp, label: 'Total faturado', value: `R$ ${avgTicket?.total?.toFixed(2) || '0,00'}`, color: 'from-green-500 to-green-700' },
          { icon: Scissors, label: 'Total serviços', value: avgTicket?.count || 0, color: 'from-blue-500 to-blue-700' },
          { icon: Users, label: 'Clientes inativos', value: inactive?.length || 0, color: 'from-amber-500 to-amber-700' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="stat-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
              </div>
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Best Days Radar */}
        <div className="card p-6">
          <h2 className="section-title mb-4">Melhores dias da semana</h2>
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart data={bestDays || []}>
              <PolarGrid stroke="#ffffff15" />
              <PolarAngleAxis dataKey="day" tick={{ fontSize: 12, fill: '#9ca3af' }} />
              <Radar name="Agendamentos" dataKey="count" stroke="#f9244d" fill="#f9244d" fillOpacity={0.2} strokeWidth={2} />
              <Tooltip contentStyle={{ background: '#16162a', border: '1px solid #252542', borderRadius: '12px', fontSize: '12px' }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Top Services Bar */}
        <div className="card p-6">
          <h2 className="section-title mb-4">Serviços mais realizados</h2>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={(topServices || []).slice(0, 6)} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="service.name" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} width={100} />
              <Tooltip
                formatter={(v: number) => [v, 'Realizações']}
                contentStyle={{ background: '#16162a', border: '1px solid #252542', borderRadius: '12px', fontSize: '12px' }}
              />
              <Bar dataKey="count" fill="#6366f1" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Employees */}
      <div className="card p-6">
        <h2 className="section-title mb-4">Profissional que mais fatura</h2>
        <div className="space-y-3">
          {(topEmployees || []).slice(0, 5).map((e: any, i: number) => {
            const pct = Math.min(100, (e.total / ((topEmployees as any[])?.[0]?.total || 1)) * 100);
            return (
              <div key={i} className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                  {e.employee?.name?.[0]}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">{e.employee?.name}</span>
                    <span className="text-sm font-bold text-brand-600 dark:text-brand-400">R$ {e.total?.toFixed(2)}</span>
                  </div>
                  <div className="h-2 bg-gray-100 dark:bg-dark-700 rounded-full">
                    <div className="h-full bg-gradient-to-r from-brand-500 to-brand-600 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{e.count} serviços · R$ {e.commission?.toFixed(2)} comissão</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Inactive Clients */}
      {(inactive?.length || 0) > 0 && (
        <div className="card p-6">
          <h2 className="section-title mb-1">Clientes inativos (45+ dias)</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Candidatos para campanha de reativação via WhatsApp</p>
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>Telefone</th>
                  <th>Última visita</th>
                  <th>Total gasto</th>
                </tr>
              </thead>
              <tbody>
                {inactive?.slice(0, 10).map((c: any) => (
                  <tr key={c.id}>
                    <td className="font-medium">{c.name}</td>
                    <td>{c.phone}</td>
                    <td className="text-red-500">{c.lastVisitAt ? new Date(c.lastVisitAt).toLocaleDateString('pt-BR') : 'Nunca'}</td>
                    <td className="font-semibold">R$ {c.totalSpent?.toFixed(2) || '0,00'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
