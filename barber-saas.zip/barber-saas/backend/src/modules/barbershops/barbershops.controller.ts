import { Controller, Get, Patch, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { BarbershopsService } from './barbershops.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('barbershops')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'barbershops', version: '1' })
export class BarbershopsController {
  constructor(private readonly svc: BarbershopsService) {}

  @Get('me')    getMe(@CurrentUser() u: any) { return this.svc.findOne(u.barbershopId); }
  @Patch(':id') update(@Param('id') id: string, @Body() dto: any) { return this.svc.update(id, dto); }
}
