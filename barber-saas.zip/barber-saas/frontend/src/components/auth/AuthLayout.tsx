import { Outlet, Link } from 'react-router-dom';
import { Scissors } from 'lucide-react';

export default function AuthLayout() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-800 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-brand-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-brand-900/20 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-950/10 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 shadow-glow mb-4">
            <Scissors className="w-7 h-7 text-white" />
          </div>
          <h1 className="font-display text-3xl font-bold text-white">BarberOS</h1>
          <p className="text-gray-400 text-sm mt-1">Sistema de gestão para barbearias</p>
        </div>

        <div className="card bg-dark-800/90 border-dark-600 p-8 backdrop-blur-xl">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
