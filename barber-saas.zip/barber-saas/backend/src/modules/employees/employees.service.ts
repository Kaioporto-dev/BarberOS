import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class EmployeesService {
  constructor(private prisma: PrismaService) {}

  async findAll(barbershopId: string, { isActive }: any = {}) {
    const where: any = { barbershopId };
    if (isActive !== undefined) where.isActive = isActive === 'true' || isActive === true;
    const items = await this.prisma.employee.findMany({
      where, orderBy: { position: 'asc' },
      include: { services: { include: { service: true } }, workingHours: true },
    });
    return { total: items.length, items };
  }

  async findOne(barbershopId: string, id: string) {
    const e = await this.prisma.employee.findFirst({
      where: { id, barbershopId },
      include: { services: { include: { service: true } }, workingHours: true },
    });
    if (!e) throw new NotFoundException('Profissional não encontrado');
    return e;
  }

  async create(barbershopId: string, dto: any) {
    const { services: svcIds, workingHours, ...data } = dto;
    return this.prisma.employee.create({
      data: {
        ...data, barbershopId,
        ...(svcIds?.length && {
          services: { create: svcIds.map((sid: string) => ({ serviceId: sid })) },
        }),
      },
      include: { services: true },
    });
  }

  async update(barbershopId: string, id: string, dto: any) {
    await this.findOne(barbershopId, id);
    const { services: svcIds, ...data } = dto;
    return this.prisma.employee.update({ where: { id }, data, include: { services: true } });
  }

  async delete(barbershopId: string, id: string) {
    await this.findOne(barbershopId, id);
    return this.prisma.employee.update({ where: { id }, data: { isActive: false } });
  }
}
