import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed do banco de dados...');

  // Cria barbearia demo
  const barbershop = await prisma.barbershop.upsert({
    where: { slug: 'barbearia-demo' },
    update: {},
    create: {
      slug: 'barbearia-demo',
      name: 'Barbearia Premium Demo',
      description: 'A melhor barbearia da cidade. Tradição e estilo desde 2010.',
      phone: '(11) 99999-9999',
      email: 'contato@barbearia-demo.com',
      address: 'Rua das Flores, 123',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01310-000',
      primaryColor: '#1a1a2e',
      accentColor: '#e94560',
    },
  });

  // Usuário owner
  const hashedPassword = await bcrypt.hash('Demo@1234', 12);
  await prisma.user.upsert({
    where: { email: 'admin@demo.com' },
    update: {},
    create: {
      email: 'admin@demo.com',
      password: hashedPassword,
      name: 'João Silva',
      role: 'OWNER',
      barbershopId: barbershop.id,
    },
  });

  // Horários de funcionamento
  const days = [
    { day: 'MONDAY', open: '09:00', close: '19:00' },
    { day: 'TUESDAY', open: '09:00', close: '19:00' },
    { day: 'WEDNESDAY', open: '09:00', close: '19:00' },
    { day: 'THURSDAY', open: '09:00', close: '20:00' },
    { day: 'FRIDAY', open: '09:00', close: '20:00' },
    { day: 'SATURDAY', open: '08:00', close: '18:00' },
    { day: 'SUNDAY', open: '09:00', close: '14:00', isOpen: false },
  ];

  for (const d of days) {
    await prisma.workingHours.upsert({
      where: { barbershopId_dayOfWeek: { barbershopId: barbershop.id, dayOfWeek: d.day as any } },
      update: {},
      create: {
        barbershopId: barbershop.id,
        dayOfWeek: d.day as any,
        isOpen: d.isOpen !== false,
        openTime: d.open,
        closeTime: d.close,
      },
    });
  }

  // Serviços
  const services = await Promise.all([
    prisma.service.create({ data: { barbershopId: barbershop.id, name: 'Corte Masculino', description: 'Corte moderno e personalizado', duration: 45, price: 45, position: 1 } }),
    prisma.service.create({ data: { barbershopId: barbershop.id, name: 'Barba', description: 'Aparar e modelar a barba com toalha quente', duration: 30, price: 35, position: 2 } }),
    prisma.service.create({ data: { barbershopId: barbershop.id, name: 'Combo Cabelo + Barba', description: 'Corte + barba com desconto especial', duration: 70, price: 70, position: 3 } }),
    prisma.service.create({ data: { barbershopId: barbershop.id, name: 'Hidratação Capilar', description: 'Tratamento completo para os cabelos', duration: 60, price: 55, position: 4 } }),
    prisma.service.create({ data: { barbershopId: barbershop.id, name: 'Sobrancelha', description: 'Design de sobrancelha masculina', duration: 20, price: 25, position: 5 } }),
  ]);

  // Funcionários
  const employees = await Promise.all([
    prisma.employee.create({ data: { barbershopId: barbershop.id, name: 'Carlos Eduardo', phone: '(11) 98888-1111', bio: '10 anos de experiência em cortes modernos', commission: 40, position: 1 } }),
    prisma.employee.create({ data: { barbershopId: barbershop.id, name: 'Rafael Santos', phone: '(11) 98888-2222', bio: 'Especialista em barba e degradê', commission: 40, position: 2 } }),
    prisma.employee.create({ data: { barbershopId: barbershop.id, name: 'Lucas Mendes', phone: '(11) 98888-3333', bio: 'Expert em coloração masculina', commission: 45, position: 3 } }),
  ]);

  // Horários dos funcionários
  const workDays = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
  for (const emp of employees) {
    for (const day of workDays) {
      await prisma.employeeWorkingHours.create({
        data: {
          employeeId: emp.id,
          dayOfWeek: day as any,
          isWorking: true,
          startTime: '09:00',
          endTime: day === 'SATURDAY' ? '17:00' : '19:00',
        },
      });
    }
  }

  // Clientes
  const clientNames = [
    ['Pedro Alves', '(11) 97001-0001'],
    ['Marcos Costa', '(11) 97001-0002'],
    ['Felipe Lima', '(11) 97001-0003'],
    ['André Oliveira', '(11) 97001-0004'],
    ['Bruno Ferreira', '(11) 97001-0005'],
    ['Diego Souza', '(11) 97001-0006'],
    ['Eduardo Rocha', '(11) 97001-0007'],
    ['Gabriel Martins', '(11) 97001-0008'],
  ];

  const clients = await Promise.all(
    clientNames.map(([name, phone]) =>
      prisma.client.create({
        data: { barbershopId: barbershop.id, name, phone, totalVisits: Math.floor(Math.random() * 20), totalSpent: Math.random() * 1000 },
      })
    )
  );

  // Cupom de desconto
  await prisma.coupon.create({
    data: {
      barbershopId: barbershop.id,
      code: 'PRIMEIRAVISITA',
      description: '20% de desconto na primeira visita',
      discountType: 'PERCENT',
      discountValue: 20,
      maxUses: 100,
      isActive: true,
    },
  });

  // Subscription
  await prisma.barbershopSubscription.upsert({
    where: { id: 'seed-sub-1' },
    update: {},
    create: {
      id: 'seed-sub-1',
      barbershopId: barbershop.id,
      plan: 'PRO',
      status: 'ACTIVE',
    },
  });

  console.log('✅ Seed concluído!');
  console.log(`📋 Barbearia: ${barbershop.name} (slug: ${barbershop.slug})`);
  console.log('👤 Login admin: admin@demo.com / Demo@1234');
  console.log(`🌐 Página pública: http://localhost:3000/${barbershop.slug}`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
