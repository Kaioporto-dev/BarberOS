import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateAppointmentDto } from './dto/create-appointment.dto';
import { UpdateAppointmentDto } from './dto/update-appointment.dto';
import { NotificationsService } from '../notifications/notifications.service';
import * as dayjs from 'dayjs';

@Injectable()
export class AppointmentsService {
  constructor(
    private prisma: PrismaService,
    private notifications: NotificationsService,
  ) {}

  async create(barbershopId: string, dto: CreateAppointmentDto) {
    // Valida serviço
    const service = await this.prisma.service.findFirst({
      where: { id: dto.serviceId, barbershopId, isActive: true },
    });
    if (!service) throw new NotFoundException('Serviço não encontrado');

    // Valida funcionário
    const employee = await this.prisma.employee.findFirst({
      where: { id: dto.employeeId, barbershopId, isActive: true },
    });
    if (!employee) throw new NotFoundException('Profissional não encontrado');

    // Calcula horário de fim
    const startAt = new Date(dto.startAt);
    const endAt = dayjs(startAt).add(service.duration, 'minute').toDate();

    // Verifica conflito de horário
    await this.checkConflict(dto.employeeId, startAt, endAt);

    // Valida cupom
    let discount = 0;
    let couponId: string | undefined;
    if (dto.couponCode) {
      const coupon = await this.validateCoupon(barbershopId, dto.couponCode, service.price);
      discount = coupon.discount;
      couponId = coupon.id;
    }

    // Cria/busca cliente
    let client = await this.prisma.client.findFirst({
      where: { barbershopId, phone: dto.clientPhone },
    });

    if (!client) {
      client = await this.prisma.client.create({
        data: {
          barbershopId,
          name: dto.clientName,
          phone: dto.clientPhone,
          email: dto.clientEmail,
        },
      });
    }

    const finalPrice = Math.max(0, service.price - discount);

    const appointment = await this.prisma.appointment.create({
      data: {
        barbershopId,
        clientId: client.id,
        employeeId: dto.employeeId,
        serviceId: dto.serviceId,
        couponId,
        startAt,
        endAt,
        status: 'PENDING',
        originalPrice: service.price,
        discount,
        finalPrice,
        notes: dto.notes,
      },
      include: {
        client: true,
        employee: true,
        service: true,
        barbershop: true,
      },
    });

    // Atualiza contagem do cupom
    if (couponId) {
      await this.prisma.coupon.update({
        where: { id: couponId },
        data: { usedCount: { increment: 1 } },
      });
    }

    // Envia confirmação (assíncrono)
    this.notifications.sendConfirmation(appointment).catch(console.error);

    return appointment;
  }

  async findAll(barbershopId: string, filters: {
    date?: string;
    employeeId?: string;
    status?: string;
    clientId?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    limit?: number;
  }) {
    const { date, employeeId, status, clientId, startDate, endDate, page = 1, limit = 50 } = filters;

    const where: any = { barbershopId };

    if (date) {
      const start = dayjs(date).startOf('day').toDate();
      const end = dayjs(date).endOf('day').toDate();
      where.startAt = { gte: start, lte: end };
    } else if (startDate || endDate) {
      where.startAt = {};
      if (startDate) where.startAt.gte = new Date(startDate);
      if (endDate) where.startAt.lte = dayjs(endDate).endOf('day').toDate();
    }

    if (employeeId) where.employeeId = employeeId;
    if (status) where.status = status;
    if (clientId) where.clientId = clientId;

    const [total, items] = await Promise.all([
      this.prisma.appointment.count({ where }),
      this.prisma.appointment.findMany({
        where,
        include: {
          client: { select: { id: true, name: true, phone: true, avatarUrl: true } },
          employee: { select: { id: true, name: true, avatarUrl: true } },
          service: { select: { id: true, name: true, duration: true, price: true } },
          payment: { select: { id: true, status: true, method: true, amount: true } },
        },
        orderBy: { startAt: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
    ]);

    return { total, page, limit, items };
  }

  async findOne(barbershopId: string, id: string) {
    const appointment = await this.prisma.appointment.findFirst({
      where: { id, barbershopId },
      include: {
        client: true,
        employee: true,
        service: true,
        barbershop: true,
        payment: true,
        review: true,
        coupon: true,
      },
    });
    if (!appointment) throw new NotFoundException('Agendamento não encontrado');
    return appointment;
  }

  async update(barbershopId: string, id: string, dto: UpdateAppointmentDto) {
    const appointment = await this.findOne(barbershopId, id);

    if (['COMPLETED', 'CANCELLED'].includes(appointment.status)) {
      throw new BadRequestException('Não é possível editar agendamento concluído ou cancelado');
    }

    return this.prisma.appointment.update({
      where: { id },
      data: {
        ...dto,
        ...(dto.startAt && {
          endAt: dayjs(dto.startAt).add(appointment.service.duration, 'minute').toDate(),
        }),
      },
      include: { client: true, employee: true, service: true },
    });
  }

  async updateStatus(barbershopId: string, id: string, status: string, reason?: string) {
    const appointment = await this.findOne(barbershopId, id);

    const updateData: any = { status };
    if (status === 'CONFIRMED') updateData.confirmedAt = new Date();
    if (status === 'COMPLETED') {
      updateData.completedAt = new Date();
      await this.updateClientStats(appointment.clientId, appointment.finalPrice);
    }
    if (status === 'CANCELLED') {
      updateData.cancelledAt = new Date();
      updateData.cancelReason = reason;
      this.notifications.sendCancellation(appointment).catch(console.error);
    }

    return this.prisma.appointment.update({
      where: { id },
      data: updateData,
      include: { client: true, employee: true, service: true },
    });
  }

  async getAvailableSlots(barbershopId: string, employeeId: string, date: string, serviceId: string) {
    const service = await this.prisma.service.findFirst({ where: { id: serviceId, barbershopId } });
    if (!service) throw new NotFoundException('Serviço não encontrado');

    const dayOfWeek = dayjs(date).format('dddd').toUpperCase() as any;
    const dayMap: Record<string, string> = {
      MONDAY: 'MONDAY', TUESDAY: 'TUESDAY', WEDNESDAY: 'WEDNESDAY',
      THURSDAY: 'THURSDAY', FRIDAY: 'FRIDAY', SATURDAY: 'SATURDAY', SUNDAY: 'SUNDAY',
    };

    const workingHours = await this.prisma.employeeWorkingHours.findFirst({
      where: { employeeId, dayOfWeek: dayMap[dayjs(date).locale('en').format('dddd').toUpperCase()] as any },
    }) || await this.prisma.workingHours.findFirst({
      where: { barbershopId, dayOfWeek: dayMap[dayjs(date).locale('en').format('dddd').toUpperCase()] as any },
    });

    if (!workingHours || !workingHours.isOpen) return [];

    // Busca agendamentos existentes do dia
    const existing = await this.prisma.appointment.findMany({
      where: {
        employeeId,
        startAt: { gte: dayjs(date).startOf('day').toDate(), lte: dayjs(date).endOf('day').toDate() },
        status: { notIn: ['CANCELLED'] },
      },
    });

    // Busca bloqueios
    const blocked = await this.prisma.blockedSlot.findMany({
      where: {
        barbershopId,
        OR: [{ employeeId }, { employeeId: null }],
        startAt: { lte: dayjs(date).endOf('day').toDate() },
        endAt: { gte: dayjs(date).startOf('day').toDate() },
      },
    });

    // Gera slots disponíveis de 30 em 30 minutos
    const slots: { time: string; available: boolean }[] = [];
    const openTime = (workingHours as any).openTime || (workingHours as any).startTime || '09:00';
    const closeTime = (workingHours as any).closeTime || (workingHours as any).endTime || '18:00';

    let current = dayjs(`${date} ${openTime}`);
    const end = dayjs(`${date} ${closeTime}`);

    while (current.isBefore(end.subtract(service.duration, 'minute'))) {
      const slotEnd = current.add(service.duration, 'minute');

      const isBooked = existing.some(
        (a) => current.toDate() < a.endAt && slotEnd.toDate() > a.startAt,
      );
      const isBlocked = blocked.some(
        (b) => current.toDate() < b.endAt && slotEnd.toDate() > b.startAt,
      );
      const isPast = current.isBefore(dayjs());

      slots.push({
        time: current.format('HH:mm'),
        available: !isBooked && !isBlocked && !isPast,
      });

      current = current.add(30, 'minute');
    }

    return slots;
  }

  private async checkConflict(employeeId: string, startAt: Date, endAt: Date) {
    const conflict = await this.prisma.appointment.findFirst({
      where: {
        employeeId,
        status: { notIn: ['CANCELLED'] },
        AND: [{ startAt: { lt: endAt } }, { endAt: { gt: startAt } }],
      },
    });
    if (conflict) throw new ConflictException('Horário já ocupado');
  }

  private async validateCoupon(barbershopId: string, code: string, price: number) {
    const coupon = await this.prisma.coupon.findFirst({
      where: {
        barbershopId,
        code: code.toUpperCase(),
        isActive: true,
        OR: [{ validUntil: null }, { validUntil: { gte: new Date() } }],
        OR: [{ maxUses: null }, { maxUses: { gt: this.prisma.coupon.fields.usedCount } }],
      },
    });
    if (!coupon) throw new BadRequestException('Cupom inválido ou expirado');
    if (coupon.minValue && price < coupon.minValue) {
      throw new BadRequestException(`Valor mínimo para este cupom: R$ ${coupon.minValue}`);
    }

    const discount = coupon.discountType === 'PERCENT'
      ? (price * coupon.discountValue) / 100
      : coupon.discountValue;

    return { id: coupon.id, discount };
  }

  private async updateClientStats(clientId: string, amount: number) {
    const client = await this.prisma.client.findUnique({ where: { id: clientId } });
    if (!client) return;

    const newTotal = client.totalSpent + amount;
    const newVisits = client.totalVisits + 1;

    await this.prisma.client.update({
      where: { id: clientId },
      data: {
        totalVisits: newVisits,
        totalSpent: newTotal,
        averageTicket: newTotal / newVisits,
        lastVisitAt: new Date(),
      },
    });
  }
}
