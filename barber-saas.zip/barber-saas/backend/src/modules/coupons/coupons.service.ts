import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CouponsService {
  constructor(private prisma: PrismaService) {}

  async findAll(barbershopId: string) {
    return this.prisma.coupon.findMany({ where: { barbershopId }, orderBy: { createdAt: 'desc' } });
  }

  async create(barbershopId: string, dto: any) {
    return this.prisma.coupon.create({ data: { ...dto, barbershopId, code: dto.code.toUpperCase() } });
  }

  async update(barbershopId: string, id: string, dto: any) {
    const c = await this.prisma.coupon.findFirst({ where: { id, barbershopId } });
    if (!c) throw new NotFoundException('Cupom não encontrado');
    return this.prisma.coupon.update({ where: { id }, data: dto });
  }

  async delete(barbershopId: string, id: string) {
    const c = await this.prisma.coupon.findFirst({ where: { id, barbershopId } });
    if (!c) throw new NotFoundException('Cupom não encontrado');
    return this.prisma.coupon.update({ where: { id }, data: { isActive: false } });
  }

  async validate(barbershopId: string, code: string, price?: number) {
    const coupon = await this.prisma.coupon.findFirst({
      where: {
        barbershopId, code: code.toUpperCase(), isActive: true,
        OR: [{ validUntil: null }, { validUntil: { gte: new Date() } }],
      },
    });
    if (!coupon) throw new BadRequestException('Cupom inválido ou expirado');
    if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) throw new BadRequestException('Cupom esgotado');
    if (coupon.minValue && price && price < coupon.minValue) throw new BadRequestException(`Valor mínimo: R$ ${coupon.minValue}`);
    const discount = coupon.discountType === 'PERCENT' && price ? (price * coupon.discountValue) / 100 : coupon.discountValue;
    return { coupon, discount };
  }
}
