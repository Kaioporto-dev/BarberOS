import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import * as dayjs from 'dayjs';

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  async getDashboard(barbershopId: string) {
    const today = dayjs().startOf('day').toDate();
    const todayEnd = dayjs().endOf('day').toDate();
    const monthStart = dayjs().startOf('month').toDate();
    const monthEnd = dayjs().endOf('month').toDate();
    const lastMonthStart = dayjs().subtract(1, 'month').startOf('month').toDate();
    const lastMonthEnd = dayjs().subtract(1, 'month').endOf('month').toDate();

    const [
      todayAppointments,
      monthAppointments,
      lastMonthAppointments,
      todayRevenue,
      monthRevenue,
      lastMonthRevenue,
      newClientsMonth,
      pendingToday,
    ] = await Promise.all([
      this.prisma.appointment.count({
        where: { barbershopId, startAt: { gte: today, lte: todayEnd }, status: { notIn: ['CANCELLED'] } },
      }),
      this.prisma.appointment.count({
        where: { barbershopId, startAt: { gte: monthStart, lte: monthEnd }, status: { notIn: ['CANCELLED'] } },
      }),
      this.prisma.appointment.count({
        where: { barbershopId, startAt: { gte: lastMonthStart, lte: lastMonthEnd }, status: { notIn: ['CANCELLED'] } },
      }),
      this.prisma.payment.aggregate({
        where: { barbershopId, status: 'PAID', paidAt: { gte: today, lte: todayEnd } },
        _sum: { amount: true },
      }),
      this.prisma.payment.aggregate({
        where: { barbershopId, status: 'PAID', paidAt: { gte: monthStart, lte: monthEnd } },
        _sum: { amount: true },
      }),
      this.prisma.payment.aggregate({
        where: { barbershopId, status: 'PAID', paidAt: { gte: lastMonthStart, lte: lastMonthEnd } },
        _sum: { amount: true },
      }),
      this.prisma.client.count({
        where: { barbershopId, createdAt: { gte: monthStart } },
      }),
      this.prisma.appointment.count({
        where: { barbershopId, startAt: { gte: today, lte: todayEnd }, status: 'PENDING' },
      }),
    ]);

    const monthRevenueVal = monthRevenue._sum.amount || 0;
    const lastMonthRevenueVal = lastMonthRevenue._sum.amount || 0;
    const revenueGrowth = lastMonthRevenueVal > 0
      ? ((monthRevenueVal - lastMonthRevenueVal) / lastMonthRevenueVal) * 100
      : 0;

    const appointmentGrowth = lastMonthAppointments > 0
      ? ((monthAppointments - lastMonthAppointments) / lastMonthAppointments) * 100
      : 0;

    return {
      today: {
        appointments: todayAppointments,
        revenue: todayRevenue._sum.amount || 0,
        pending: pendingToday,
      },
      month: {
        appointments: monthAppointments,
        revenue: monthRevenueVal,
        newClients: newClientsMonth,
        revenueGrowth: Math.round(revenueGrowth * 10) / 10,
        appointmentGrowth: Math.round(appointmentGrowth * 10) / 10,
      },
    };
  }

  async getRevenueByPeriod(barbershopId: string, startDate: string, endDate: string) {
    const payments = await this.prisma.payment.findMany({
      where: {
        barbershopId,
        status: 'PAID',
        paidAt: { gte: new Date(startDate), lte: dayjs(endDate).endOf('day').toDate() },
      },
      include: { appointment: { include: { service: true, employee: true } } },
      orderBy: { paidAt: 'asc' },
    });

    // Agrupa por dia
    const byDay: Record<string, { date: string; total: number; count: number }> = {};
    for (const payment of payments) {
      const day = dayjs(payment.paidAt).format('YYYY-MM-DD');
      if (!byDay[day]) byDay[day] = { date: day, total: 0, count: 0 };
      byDay[day].total += payment.amount;
      byDay[day].count++;
    }

    return Object.values(byDay);
  }

  async getTopEmployees(barbershopId: string, startDate?: string, endDate?: string) {
    const where: any = { barbershopId, status: 'PAID' };
    if (startDate || endDate) {
      where.paidAt = {};
      if (startDate) where.paidAt.gte = new Date(startDate);
      if (endDate) where.paidAt.lte = dayjs(endDate).endOf('day').toDate();
    }

    const payments = await this.prisma.payment.findMany({
      where,
      include: {
        appointment: {
          include: { employee: { select: { id: true, name: true, avatarUrl: true } } },
        },
      },
    });

    const byEmployee: Record<string, { employee: any; total: number; count: number; commission: number }> = {};
    for (const payment of payments) {
      const emp = payment.appointment?.employee;
      if (!emp) continue;
      if (!byEmployee[emp.id]) {
        byEmployee[emp.id] = { employee: emp, total: 0, count: 0, commission: 0 };
      }
      byEmployee[emp.id].total += payment.amount;
      byEmployee[emp.id].count++;
      byEmployee[emp.id].commission += payment.employeeCommission;
    }

    return Object.values(byEmployee).sort((a, b) => b.total - a.total);
  }

  async getTopServices(barbershopId: string, startDate?: string, endDate?: string) {
    const where: any = { barbershopId, status: { notIn: ['CANCELLED'] } };
    if (startDate || endDate) {
      where.startAt = {};
      if (startDate) where.startAt.gte = new Date(startDate);
      if (endDate) where.startAt.lte = dayjs(endDate).endOf('day').toDate();
    }

    const appointments = await this.prisma.appointment.findMany({
      where,
      include: { service: { select: { id: true, name: true, price: true } } },
    });

    const byService: Record<string, { service: any; total: number; count: number }> = {};
    for (const apt of appointments) {
      const svc = apt.service;
      if (!byService[svc.id]) byService[svc.id] = { service: svc, total: 0, count: 0 };
      byService[svc.id].total += apt.finalPrice;
      byService[svc.id].count++;
    }

    return Object.values(byService).sort((a, b) => b.count - a.count);
  }

  async getBestDays(barbershopId: string) {
    const appointments = await this.prisma.appointment.findMany({
      where: {
        barbershopId,
        status: 'COMPLETED',
        startAt: { gte: dayjs().subtract(90, 'day').toDate() },
      },
      select: { startAt: true, finalPrice: true },
    });

    const byDay: Record<string, { day: string; total: number; count: number }> = {
      '0': { day: 'Domingo', total: 0, count: 0 },
      '1': { day: 'Segunda', total: 0, count: 0 },
      '2': { day: 'Terça', total: 0, count: 0 },
      '3': { day: 'Quarta', total: 0, count: 0 },
      '4': { day: 'Quinta', total: 0, count: 0 },
      '5': { day: 'Sexta', total: 0, count: 0 },
      '6': { day: 'Sábado', total: 0, count: 0 },
    };

    for (const apt of appointments) {
      const dow = dayjs(apt.startAt).day().toString();
      byDay[dow].total += apt.finalPrice;
      byDay[dow].count++;
    }

    return Object.values(byDay);
  }

  async getAverageTicket(barbershopId: string) {
    const result = await this.prisma.payment.aggregate({
      where: { barbershopId, status: 'PAID' },
      _avg: { amount: true },
      _sum: { amount: true },
      _count: { id: true },
    });

    return {
      average: result._avg.amount || 0,
      total: result._sum.amount || 0,
      count: result._count.id,
    };
  }

  async getInactiveClients(barbershopId: string, days = 45) {
    const cutoff = dayjs().subtract(days, 'day').toDate();
    return this.prisma.client.findMany({
      where: {
        barbershopId,
        isActive: true,
        OR: [
          { lastVisitAt: { lte: cutoff } },
          { lastVisitAt: null, createdAt: { lte: cutoff } },
        ],
      },
      orderBy: { lastVisitAt: 'asc' },
      take: 100,
    });
  }

  async getDailyCashFlow(barbershopId: string, date: string) {
    const start = dayjs(date).startOf('day').toDate();
    const end = dayjs(date).endOf('day').toDate();

    const [payments, appointments] = await Promise.all([
      this.prisma.payment.findMany({
        where: { barbershopId, paidAt: { gte: start, lte: end } },
        include: {
          appointment: {
            include: {
              client: { select: { name: true } },
              service: { select: { name: true } },
              employee: { select: { name: true } },
            },
          },
        },
        orderBy: { paidAt: 'asc' },
      }),
      this.prisma.appointment.findMany({
        where: {
          barbershopId,
          startAt: { gte: start, lte: end },
          status: { notIn: ['CANCELLED'] },
        },
        include: {
          client: { select: { name: true } },
          service: { select: { name: true } },
          employee: { select: { name: true } },
        },
        orderBy: { startAt: 'asc' },
      }),
    ]);

    const totalPaid = payments.filter(p => p.status === 'PAID').reduce((sum, p) => sum + p.amount, 0);
    const byMethod: Record<string, number> = {};
    for (const p of payments.filter(pm => pm.status === 'PAID')) {
      byMethod[p.method] = (byMethod[p.method] || 0) + p.amount;
    }

    return { date, totalPaid, byMethod, payments, appointments };
  }
}
