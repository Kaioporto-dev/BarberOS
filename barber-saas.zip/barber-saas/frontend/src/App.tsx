import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuthStore } from './store/auth.store';
import { useThemeStore } from './store/theme.store';

// Layouts
import AdminLayout from './components/admin/AdminLayout';
import AuthLayout from './components/auth/AuthLayout';

// Auth Pages
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';

// Admin Pages
import DashboardPage from './pages/admin/DashboardPage';
import AppointmentsPage from './pages/admin/AppointmentsPage';
import CalendarPage from './pages/admin/CalendarPage';
import ClientsPage from './pages/admin/ClientsPage';
import ServicesPage from './pages/admin/ServicesPage';
import EmployeesPage from './pages/admin/EmployeesPage';
import FinancialPage from './pages/admin/FinancialPage';
import ReportsPage from './pages/admin/ReportsPage';
import CouponsPage from './pages/admin/CouponsPage';
import SettingsPage from './pages/admin/SettingsPage';

// Public Booking Pages
import BookingPage from './pages/client/BookingPage';
import BookingConfirmPage from './pages/client/BookingConfirmPage';

// Guards
const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuthStore();
  return isAuthenticated ? <>{children}</> : <Navigate to="/admin/login" replace />;
};

export default function App() {
  const { isDark } = useThemeStore();

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
  }, [isDark]);

  return (
    <BrowserRouter>
      <Routes>
        {/* Public booking routes */}
        <Route path="/:slug" element={<BookingPage />} />
        <Route path="/:slug/confirm" element={<BookingConfirmPage />} />

        {/* Auth routes */}
        <Route element={<AuthLayout />}>
          <Route path="/admin/login" element={<LoginPage />} />
          <Route path="/admin/register" element={<RegisterPage />} />
        </Route>

        {/* Admin routes */}
        <Route path="/admin" element={<PrivateRoute><AdminLayout /></PrivateRoute>}>
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="calendar" element={<CalendarPage />} />
          <Route path="appointments" element={<AppointmentsPage />} />
          <Route path="clients" element={<ClientsPage />} />
          <Route path="services" element={<ServicesPage />} />
          <Route path="employees" element={<EmployeesPage />} />
          <Route path="financial" element={<FinancialPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="coupons" element={<CouponsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>

        {/* Redirect root to demo */}
        <Route path="/" element={<Navigate to="/admin/login" replace />} />
        <Route path="*" element={<Navigate to="/admin/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
