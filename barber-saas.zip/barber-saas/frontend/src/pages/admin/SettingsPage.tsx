// SettingsPage.tsx
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Save, Loader2, Globe, Palette, Clock, Bell } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuthStore } from '../../store/auth.store';
import { api } from '../../services/api';

export default function SettingsPage() {
  const { barbershop, updateBarbershop } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit } = useForm({ defaultValues: barbershop || {} });

  const onSubmit = async (data: any) => {
    setLoading(true);
    try {
      const res = await api.patch(`/barbershops/${barbershop?.id}`, data);
      updateBarbershop(res.data.data);
      toast.success('Configurações salvas!');
    } catch { toast.error('Erro ao salvar'); }
    finally { setLoading(false); }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="page-title">Configurações</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Info */}
        <div className="card p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2"><Globe className="w-4 h-4 text-brand-500" /><h2 className="section-title">Informações da barbearia</h2></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><label className="label">Nome da barbearia</label><input {...register('name')} className="input" /></div>
            <div className="col-span-2"><label className="label">Descrição</label><textarea {...register('description')} rows={3} className="input resize-none" /></div>
            <div><label className="label">Telefone</label><input {...register('phone')} className="input" /></div>
            <div><label className="label">E-mail</label><input {...register('email')} type="email" className="input" /></div>
            <div className="col-span-2"><label className="label">Endereço</label><input {...register('address')} className="input" /></div>
            <div><label className="label">Cidade</label><input {...register('city')} className="input" /></div>
            <div><label className="label">Estado</label><input {...register('state')} className="input" placeholder="SP" /></div>
          </div>
        </div>

        {/* Aparência */}
        <div className="card p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2"><Palette className="w-4 h-4 text-brand-500" /><h2 className="section-title">Personalização</h2></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="label">Cor principal</label><input {...register('primaryColor')} type="color" className="w-full h-10 rounded-xl border border-gray-200 dark:border-dark-600 cursor-pointer" /></div>
            <div><label className="label">Cor de destaque</label><input {...register('accentColor')} type="color" className="w-full h-10 rounded-xl border border-gray-200 dark:border-dark-600 cursor-pointer" /></div>
          </div>
          <div>
            <label className="label">URL pública</label>
            <div className="flex items-center input gap-2 py-2">
              <span className="text-gray-400 text-sm">barberos.app/</span>
              <input {...register('slug')} className="flex-1 bg-transparent focus:outline-none text-sm font-mono" />
            </div>
          </div>
        </div>

        {/* Agendamento */}
        <div className="card p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2"><Clock className="w-4 h-4 text-brand-500" /><h2 className="section-title">Configurações de agendamento</h2></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="label">Janela de agendamento (dias)</label><input {...register('bookingWindow')} type="number" className="input" /><p className="text-xs text-gray-400 mt-1">Quantos dias à frente o cliente pode agendar</p></div>
            <div><label className="label">Cancelamento (horas antes)</label><input {...register('cancelWindow')} type="number" className="input" /><p className="text-xs text-gray-400 mt-1">Prazo mínimo para cancelar sem penalidade</p></div>
          </div>
        </div>

        <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4" />Salvar configurações</>}
        </button>
      </form>
    </div>
  );
}
