// ============================================================
// appointments.module.ts
// ============================================================
import { Module } from '@nestjs/common';
import { AppointmentsController } from './appointments.controller';
import { AppointmentsService } from './appointments.service';
import { NotificationsModule } from '../notifications/notifications.module';

export { AppointmentsModule } from './appointments.module.impl';
