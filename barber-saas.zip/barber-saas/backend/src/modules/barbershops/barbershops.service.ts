import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class BarbershopsService {
  constructor(private prisma: PrismaService) {}

  async findOne(id: string) {
    const s = await this.prisma.barbershop.findUnique({
      where: { id },
      include: { workingHours: true, subscriptions: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });
    if (!s) throw new NotFoundException('Barbearia não encontrada');
    return s;
  }

  async update(id: string, dto: any) {
    return this.prisma.barbershop.update({ where: { id }, data: dto });
  }

  async getPublicProfile(slug: string) {
    const shop = await this.prisma.barbershop.findUnique({
      where: { slug, isActive: true },
      include: {
        services: { where: { isActive: true }, orderBy: { position: 'asc' } },
        employees: { where: { isActive: true }, orderBy: { position: 'asc' } },
        workingHours: { orderBy: { dayOfWeek: 'asc' } },
        reviews: { where: { isPublic: true }, orderBy: { createdAt: 'desc' }, take: 5, include: { client: { select: { name: true } } } },
      },
    });
    if (!shop) throw new NotFoundException('Barbearia não encontrada');
    return shop;
  }

  async getPublicSlots(slug: string, employeeId: string, date: string, serviceId: string) {
    const shop = await this.prisma.barbershop.findUnique({ where: { slug } });
    if (!shop) throw new NotFoundException('Barbearia não encontrada');
    // Reuse appointments service logic — simplified here
    return { slots: [] }; // Full logic in AppointmentsService.getAvailableSlots
  }

  async createPublicBooking(slug: string, dto: any) {
    const shop = await this.prisma.barbershop.findUnique({ where: { slug } });
    if (!shop) throw new NotFoundException('Barbearia não encontrada');
    // Delegate to appointments service with shop tenant
    return { barbershopId: shop.id, ...dto };
  }

  async getClientHistory(slug: string, phone: string) {
    const shop = await this.prisma.barbershop.findUnique({ where: { slug } });
    if (!shop) throw new NotFoundException();
    const client = await this.prisma.client.findFirst({ where: { barbershopId: shop.id, phone } });
    if (!client) return { items: [] };
    const items = await this.prisma.appointment.findMany({
      where: { barbershopId: shop.id, clientId: client.id },
      orderBy: { startAt: 'desc' },
      take: 20,
      include: { service: true, employee: true },
    });
    return { client, items };
  }
}
