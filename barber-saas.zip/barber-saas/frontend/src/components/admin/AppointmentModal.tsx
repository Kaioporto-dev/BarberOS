import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Loader2, Trash2, CheckCircle, XCircle, Clock } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import dayjs from 'dayjs';
import toast from 'react-hot-toast';
import { appointmentsApi, servicesApi, employeesApi, clientsApi } from '../../services/api';
import clsx from 'clsx';

const schema = z.object({
  clientId: z.string().optional(),
  clientName: z.string().min(1, 'Nome obrigatório'),
  clientPhone: z.string().min(10, 'Telefone inválido'),
  clientEmail: z.string().email().optional().or(z.literal('')),
  serviceId: z.string().min(1, 'Selecione o serviço'),
  employeeId: z.string().min(1, 'Selecione o profissional'),
  startAt: z.string().min(1, 'Data/hora obrigatória'),
  notes: z.string().optional(),
  couponCode: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

interface Props {
  appointment?: any;
  slotInfo?: any;
  onClose: () => void;
  onSuccess: () => void;
}

const statusActions = [
  { status: 'CONFIRMED',   label: 'Confirmar',    icon: CheckCircle, cls: 'text-blue-600 border-blue-200 hover:bg-blue-50 dark:hover:bg-blue-950/30' },
  { status: 'IN_PROGRESS', label: 'Iniciar',       icon: Clock,       cls: 'text-purple-600 border-purple-200 hover:bg-purple-50 dark:hover:bg-purple-950/30' },
  { status: 'COMPLETED',   label: 'Concluir',      icon: CheckCircle, cls: 'text-green-600 border-green-200 hover:bg-green-50 dark:hover:bg-green-950/30' },
  { status: 'CANCELLED',   label: 'Cancelar',      icon: XCircle,     cls: 'text-red-600 border-red-200 hover:bg-red-50 dark:hover:bg-red-950/30' },
  { status: 'NO_SHOW',     label: 'Não compareceu', icon: XCircle,    cls: 'text-gray-500 border-gray-200 hover:bg-gray-50 dark:hover:bg-dark-700' },
];

export default function AppointmentModal({ appointment, slotInfo, onClose, onSuccess }: Props) {
  const isEditing = !!appointment;
  const [loading, setLoading] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(appointment?.employeeId || '');
  const [selectedService, setSelectedService] = useState(appointment?.serviceId || '');
  const [slots, setSlots] = useState<any[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);

  const { data: services } = useQuery({ queryKey: ['services'], queryFn: () => servicesApi.list({ isActive: true }) });
  const { data: employees } = useQuery({ queryKey: ['employees'], queryFn: () => employeesApi.list({ isActive: true }) });

  const defaultDate = slotInfo?.start
    ? dayjs(slotInfo.start).format('YYYY-MM-DDTHH:mm')
    : appointment?.startAt
    ? dayjs(appointment.startAt).format('YYYY-MM-DDTHH:mm')
    : dayjs().format('YYYY-MM-DDTHH:mm');

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      clientName: appointment?.client?.name || '',
      clientPhone: appointment?.client?.phone || '',
      clientEmail: appointment?.client?.email || '',
      serviceId: appointment?.serviceId || '',
      employeeId: appointment?.employeeId || '',
      startAt: defaultDate,
      notes: appointment?.notes || '',
    },
  });

  const watchDate = watch('startAt');

  // Load available slots when employee + service + date change
  useEffect(() => {
    const date = watchDate?.split('T')[0];
    if (selectedEmployee && selectedService && date) {
      setLoadingSlots(true);
      appointmentsApi.getSlots(selectedEmployee, date, selectedService)
        .then(setSlots)
        .catch(() => setSlots([]))
        .finally(() => setLoadingSlots(false));
    }
  }, [selectedEmployee, selectedService, watchDate?.split('T')[0]]);

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      if (isEditing) {
        await appointmentsApi.update(appointment.id, data);
      } else {
        await appointmentsApi.create(data);
      }
      onSuccess();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Erro ao salvar agendamento');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (status: string) => {
    setLoading(true);
    try {
      await appointmentsApi.updateStatus(appointment.id, status);
      toast.success('Status atualizado!');
      onSuccess();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Erro ao atualizar status');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Excluir este agendamento?')) return;
    setLoading(true);
    try {
      await appointmentsApi.delete(appointment.id);
      toast.success('Agendamento excluído!');
      onSuccess();
    } catch {
      toast.error('Erro ao excluir');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

      <div className="relative card w-full max-w-lg max-h-[90vh] overflow-y-auto animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-dark-700">
          <h2 className="section-title">{isEditing ? 'Editar agendamento' : 'Novo agendamento'}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status actions (edit mode) */}
        {isEditing && (
          <div className="px-6 py-3 border-b border-gray-100 dark:border-dark-700">
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">Alterar status</p>
            <div className="flex flex-wrap gap-2">
              {statusActions
                .filter(a => a.status !== appointment.status)
                .map(({ status, label, icon: Icon, cls }) => (
                  <button
                    key={status}
                    onClick={() => handleStatusChange(status)}
                    disabled={loading}
                    className={clsx('flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors', cls)}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {label}
                  </button>
                ))}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          {/* Client */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Cliente</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="label">Nome</label>
                <input {...register('clientName')} className="input" placeholder="Nome do cliente" />
                {errors.clientName && <p className="text-red-500 text-xs mt-1">{errors.clientName.message}</p>}
              </div>
              <div>
                <label className="label">Telefone</label>
                <input {...register('clientPhone')} className="input" placeholder="(11) 99999-9999" />
                {errors.clientPhone && <p className="text-red-500 text-xs mt-1">{errors.clientPhone.message}</p>}
              </div>
              <div>
                <label className="label">E-mail (opcional)</label>
                <input {...register('clientEmail')} type="email" className="input" placeholder="email@exemplo.com" />
              </div>
            </div>
          </div>

          {/* Service & Employee */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Serviço</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Serviço</label>
                <select
                  {...register('serviceId')}
                  className="input"
                  onChange={e => { setValue('serviceId', e.target.value); setSelectedService(e.target.value); }}
                >
                  <option value="">Selecione...</option>
                  {services?.items?.map((s: any) => (
                    <option key={s.id} value={s.id}>{s.name} ({s.duration}min)</option>
                  ))}
                </select>
                {errors.serviceId && <p className="text-red-500 text-xs mt-1">{errors.serviceId.message}</p>}
              </div>
              <div>
                <label className="label">Profissional</label>
                <select
                  {...register('employeeId')}
                  className="input"
                  onChange={e => { setValue('employeeId', e.target.value); setSelectedEmployee(e.target.value); }}
                >
                  <option value="">Selecione...</option>
                  {employees?.items?.map((e: any) => (
                    <option key={e.id} value={e.id}>{e.name}</option>
                  ))}
                </select>
                {errors.employeeId && <p className="text-red-500 text-xs mt-1">{errors.employeeId.message}</p>}
              </div>
            </div>
          </div>

          {/* Date/Time */}
          <div>
            <label className="label">Data e hora</label>
            <input {...register('startAt')} type="datetime-local" className="input" />
            {errors.startAt && <p className="text-red-500 text-xs mt-1">{errors.startAt.message}</p>}
          </div>

          {/* Available slots */}
          {selectedEmployee && selectedService && (
            <div>
              <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">
                Horários disponíveis {loadingSlots && <span className="text-brand-500">(carregando...)</span>}
              </p>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {slots.filter(s => s.available).slice(0, 20).map(s => (
                  <button
                    key={s.time}
                    type="button"
                    onClick={() => {
                      const date = watchDate?.split('T')[0] || dayjs().format('YYYY-MM-DD');
                      setValue('startAt', `${date}T${s.time}`);
                    }}
                    className={clsx(
                      'px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors',
                      watchDate?.includes(s.time)
                        ? 'bg-brand-600 text-white border-brand-600'
                        : 'border-gray-200 dark:border-dark-600 hover:border-brand-400 text-gray-600 dark:text-gray-300'
                    )}
                  >
                    {s.time}
                  </button>
                ))}
                {slots.filter(s => s.available).length === 0 && !loadingSlots && (
                  <p className="text-xs text-gray-400">Nenhum horário disponível neste dia</p>
                )}
              </div>
            </div>
          )}

          {/* Notes & Coupon */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Cupom (opcional)</label>
              <input {...register('couponCode')} className="input" placeholder="PRIMEIRAVISITA" />
            </div>
            <div>
              <label className="label">Observações</label>
              <input {...register('notes')} className="input" placeholder="Alguma observação..." />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-2">
            {isEditing && (
              <button type="button" onClick={handleDelete} disabled={loading}
                className="p-2.5 rounded-xl border border-red-200 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancelar</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : isEditing ? 'Salvar' : 'Agendar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
