import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ClientsService {
  constructor(private prisma: PrismaService) {}

  async findAll(barbershopId: string, { search = '', page = 1, limit = 50 }: any = {}) {
    const where: any = { barbershopId, isActive: true };
    if (search) where.OR = [
      { name: { contains: search, mode: 'insensitive' } },
      { phone: { contains: search } },
      { email: { contains: search, mode: 'insensitive' } },
    ];
    const [total, items] = await Promise.all([
      this.prisma.client.count({ where }),
      this.prisma.client.findMany({ where, orderBy: { name: 'asc' }, skip: (page - 1) * limit, take: +limit }),
    ]);
    return { total, page: +page, limit: +limit, items };
  }

  async findOne(barbershopId: string, id: string) {
    const c = await this.prisma.client.findFirst({ where: { id, barbershopId } });
    if (!c) throw new NotFoundException('Cliente não encontrado');
    return c;
  }

  async create(barbershopId: string, dto: any) {
    return this.prisma.client.create({ data: { ...dto, barbershopId } });
  }

  async update(barbershopId: string, id: string, dto: any) {
    await this.findOne(barbershopId, id);
    return this.prisma.client.update({ where: { id }, data: dto });
  }

  async delete(barbershopId: string, id: string) {
    await this.findOne(barbershopId, id);
    return this.prisma.client.update({ where: { id }, data: { isActive: false } });
  }

  async getAppointments(barbershopId: string, clientId: string, { page = 1, limit = 20 }: any = {}) {
    await this.findOne(barbershopId, clientId);
    const where = { barbershopId, clientId };
    const [total, items] = await Promise.all([
      this.prisma.appointment.count({ where }),
      this.prisma.appointment.findMany({
        where, orderBy: { startAt: 'desc' }, skip: (page - 1) * limit, take: +limit,
        include: { service: true, employee: true },
      }),
    ]);
    return { total, items };
  }
}
