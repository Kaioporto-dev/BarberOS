// ================================================
// ServicesPage.tsx
// ================================================
import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Edit2, Trash2, Clock, DollarSign, X, Loader2, ToggleLeft, ToggleRight } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import { servicesApi } from '../../services/api';

const schema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  duration: z.coerce.number().min(5).max(480),
  price: z.coerce.number().min(0),
  commission: z.coerce.number().min(0).max(100).default(0),
});
type FormData = z.infer<typeof schema>;

function ServiceModal({ service, onClose, onSuccess }: any) {
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { name: service?.name || '', description: service?.description || '', duration: service?.duration || 45, price: service?.price || 0, commission: service?.commission || 0 },
  });
  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      if (service) await servicesApi.update(service.id, data);
      else await servicesApi.create(data);
      toast.success(service ? 'Serviço atualizado!' : 'Serviço criado!');
      onSuccess();
    } catch (err: any) { toast.error(err.response?.data?.message || 'Erro'); }
    finally { setLoading(false); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-dark-700">
          <h2 className="section-title">{service ? 'Editar serviço' : 'Novo serviço'}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div><label className="label">Nome do serviço</label><input {...register('name')} className="input" placeholder="Corte Masculino" />{errors.name && <p className="text-red-500 text-xs mt-1">Obrigatório</p>}</div>
          <div><label className="label">Descrição</label><input {...register('description')} className="input" placeholder="Descrição do serviço..." /></div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="label">Duração (min)</label><input {...register('duration')} type="number" className="input" />{errors.duration && <p className="text-red-500 text-xs mt-1">Mínimo 5min</p>}</div>
            <div><label className="label">Preço (R$)</label><input {...register('price')} type="number" step="0.01" className="input" /></div>
            <div><label className="label">Comissão (%)</label><input {...register('commission')} type="number" className="input" /></div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancelar</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Salvar'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function ServicesPage() {
  const [modal, setModal] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ['services'], queryFn: () => servicesApi.list() });

  const handleSuccess = () => { qc.invalidateQueries({ queryKey: ['services'] }); setModal(false); setSelected(null); };
  const handleDelete = async (s: any) => {
    if (!confirm(`Excluir "${s.name}"?`)) return;
    try { await servicesApi.delete(s.id); toast.success('Excluído!'); qc.invalidateQueries({ queryKey: ['services'] }); } catch { toast.error('Erro'); }
  };

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Serviços</h1>
        <button className="btn-primary" onClick={() => { setSelected(null); setModal(true); }}><Plus className="w-4 h-4" />Novo serviço</button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? Array(4).fill(0).map((_, i) => <div key={i} className="card p-6 h-36 animate-pulse bg-gray-50 dark:bg-dark-700" />) :
          data?.items?.map((s: any) => (
            <div key={s.id} className="card p-5 flex flex-col gap-3 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between">
                <h3 className="font-bold text-gray-900 dark:text-white">{s.name}</h3>
                <div className="flex gap-1">
                  <button onClick={() => { setSelected(s); setModal(true); }} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30"><Edit2 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => handleDelete(s)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              {s.description && <p className="text-sm text-gray-500 dark:text-gray-400">{s.description}</p>}
              <div className="flex items-center gap-4 mt-auto">
                <div className="flex items-center gap-1 text-sm"><Clock className="w-4 h-4 text-gray-400" /><span>{s.duration}min</span></div>
                <div className="flex items-center gap-1 text-sm font-bold text-brand-600 dark:text-brand-400"><DollarSign className="w-4 h-4" /><span>R$ {s.price?.toFixed(2)}</span></div>
                {s.commission > 0 && <span className="text-xs text-gray-400">{s.commission}% comissão</span>}
              </div>
            </div>
          ))}
      </div>
      {modal && <ServiceModal service={selected} onClose={() => { setModal(false); setSelected(null); }} onSuccess={handleSuccess} />}
    </div>
  );
}
