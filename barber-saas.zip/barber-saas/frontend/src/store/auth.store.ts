// store/auth.store.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  avatarUrl?: string;
  barbershopId: string;
}

interface Barbershop {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  primaryColor: string;
  accentColor: string;
}

interface AuthState {
  user: User | null;
  barbershop: Barbershop | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  setAuth: (data: { user: User; barbershop: Barbershop; accessToken: string; refreshToken: string }) => void;
  updateUser: (user: Partial<User>) => void;
  updateBarbershop: (shop: Partial<Barbershop>) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      barbershop: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,

      setAuth: ({ user, barbershop, accessToken, refreshToken }) =>
        set({ user, barbershop, accessToken, refreshToken, isAuthenticated: true }),

      updateUser: (updates) =>
        set((s) => ({ user: s.user ? { ...s.user, ...updates } : null })),

      updateBarbershop: (updates) =>
        set((s) => ({ barbershop: s.barbershop ? { ...s.barbershop, ...updates } : null })),

      logout: () =>
        set({ user: null, barbershop: null, accessToken: null, refreshToken: null, isAuthenticated: false }),
    }),
    { name: 'barber-auth' }
  )
);
