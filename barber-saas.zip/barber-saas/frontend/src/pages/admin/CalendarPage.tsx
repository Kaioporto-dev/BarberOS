import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Calendar, dateFnsLocalizer, Views } from 'react-big-calendar';
import { format, parse, startOfWeek, getDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Plus, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import dayjs from 'dayjs';
import toast from 'react-hot-toast';
import { appointmentsApi, employeesApi } from '../../services/api';
import AppointmentModal from '../../components/admin/AppointmentModal';
import clsx from 'clsx';

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek: () => startOfWeek(new Date(), { weekStartsOn: 0 }),
  getDay,
  locales: { 'pt-BR': ptBR },
});

const statusColors: Record<string, string> = {
  PENDING:     '#f59e0b',
  CONFIRMED:   '#6366f1',
  IN_PROGRESS: '#8b5cf6',
  COMPLETED:   '#22c55e',
  CANCELLED:   '#ef4444',
  NO_SHOW:     '#6b7280',
};

const messages = {
  allDay: 'Dia inteiro',
  previous: 'Anterior',
  next: 'Próximo',
  today: 'Hoje',
  month: 'Mês',
  week: 'Semana',
  day: 'Dia',
  agenda: 'Agenda',
  date: 'Data',
  time: 'Hora',
  event: 'Evento',
  noEventsInRange: 'Nenhum agendamento neste período.',
  showMore: (n: number) => `+${n} mais`,
};

export default function CalendarPage() {
  const [view, setView] = useState<any>(Views.WEEK);
  const [date, setDate] = useState(new Date());
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedApt, setSelectedApt] = useState<any>(null);
  const [slotInfo, setSlotInfo] = useState<any>(null);
  const qc = useQueryClient();

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => employeesApi.list({ isActive: true }),
  });

  const startDate = dayjs(date).startOf(view === Views.MONTH ? 'month' : 'week').subtract(1, 'day').format('YYYY-MM-DD');
  const endDate = dayjs(date).endOf(view === Views.MONTH ? 'month' : 'week').add(1, 'day').format('YYYY-MM-DD');

  const { data: apts } = useQuery({
    queryKey: ['appointments', 'calendar', startDate, endDate, selectedEmployee],
    queryFn: () => appointmentsApi.list({
      startDate,
      endDate,
      employeeId: selectedEmployee || undefined,
      limit: 500,
    }),
  });

  const events = (apts?.items || []).map((apt: any) => ({
    id: apt.id,
    title: `${apt.client?.name} — ${apt.service?.name}`,
    start: new Date(apt.startAt),
    end: new Date(apt.endAt),
    resource: apt,
    color: statusColors[apt.status] || '#6366f1',
  }));

  const handleSelectSlot = useCallback((info: any) => {
    setSlotInfo(info);
    setSelectedApt(null);
    setModalOpen(true);
  }, []);

  const handleSelectEvent = useCallback((event: any) => {
    setSelectedApt(event.resource);
    setSlotInfo(null);
    setModalOpen(true);
  }, []);

  const eventPropGetter = useCallback((event: any) => ({
    style: {
      backgroundColor: event.color + '22',
      borderLeft: `3px solid ${event.color}`,
      color: event.color,
      borderRadius: '8px',
      fontSize: '12px',
      fontWeight: '600',
      padding: '2px 6px',
    },
  }), []);

  const navigate = (dir: 'PREV' | 'NEXT' | 'TODAY') => {
    if (dir === 'TODAY') { setDate(new Date()); return; }
    const unit = view === Views.MONTH ? 'month' : view === Views.WEEK ? 'week' : 'day';
    setDate(dayjs(date)[dir === 'PREV' ? 'subtract' : 'add'](1, unit).toDate());
  };

  const formatToolbarDate = () => {
    if (view === Views.MONTH) return dayjs(date).format('MMMM YYYY');
    if (view === Views.WEEK) {
      const start = dayjs(date).startOf('week');
      const end = dayjs(date).endOf('week');
      return `${start.format('D')} – ${end.format('D [de] MMMM YYYY')}`;
    }
    return dayjs(date).format('D [de] MMMM YYYY');
  };

  return (
    <div className="space-y-4 h-full">
      {/* Header */}
      <div className="page-header flex-wrap gap-3">
        <h1 className="page-title">Agenda</h1>
        <button className="btn-primary" onClick={() => { setSelectedApt(null); setSlotInfo(null); setModalOpen(true); }}>
          <Plus className="w-4 h-4" /> Novo agendamento
        </button>
      </div>

      {/* Toolbar */}
      <div className="card p-3 flex flex-wrap items-center gap-3">
        {/* Navigation */}
        <div className="flex items-center gap-1">
          <button className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-500" onClick={() => navigate('PREV')}>
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-gray-200 dark:border-dark-600 hover:bg-gray-50 dark:hover:bg-dark-700 text-gray-600 dark:text-gray-300"
            onClick={() => navigate('TODAY')}
          >
            Hoje
          </button>
          <button className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-500" onClick={() => navigate('NEXT')}>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <span className="text-sm font-bold text-gray-800 dark:text-white capitalize">{formatToolbarDate()}</span>

        <div className="ml-auto flex items-center gap-2 flex-wrap">
          {/* Employee filter */}
          <select
            className="input py-1.5 text-sm w-44"
            value={selectedEmployee}
            onChange={e => setSelectedEmployee(e.target.value)}
          >
            <option value="">Todos os profissionais</option>
            {employees?.items?.map((e: any) => (
              <option key={e.id} value={e.id}>{e.name}</option>
            ))}
          </select>

          {/* View switcher */}
          <div className="flex rounded-xl border border-gray-200 dark:border-dark-600 overflow-hidden">
            {[
              { key: Views.DAY, label: 'Dia' },
              { key: Views.WEEK, label: 'Semana' },
              { key: Views.MONTH, label: 'Mês' },
            ].map(v => (
              <button
                key={v.key}
                onClick={() => setView(v.key)}
                className={clsx(
                  'px-3 py-1.5 text-xs font-semibold transition-colors',
                  view === v.key
                    ? 'bg-brand-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-dark-700'
                )}
              >
                {v.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-3">
        {Object.entries(statusColors).map(([status, color]) => {
          const labels: Record<string, string> = {
            PENDING: 'Pendente', CONFIRMED: 'Confirmado', IN_PROGRESS: 'Em andamento',
            COMPLETED: 'Concluído', CANCELLED: 'Cancelado', NO_SHOW: 'Não compareceu',
          };
          return (
            <div key={status} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
              <span className="text-xs text-gray-500 dark:text-gray-400">{labels[status]}</span>
            </div>
          );
        })}
      </div>

      {/* Calendar */}
      <div className="card p-4" style={{ height: '620px' }}>
        <Calendar
          localizer={localizer}
          events={events}
          view={view}
          date={date}
          onView={setView}
          onNavigate={setDate}
          onSelectSlot={handleSelectSlot}
          onSelectEvent={handleSelectEvent}
          selectable
          eventPropGetter={eventPropGetter}
          messages={messages}
          culture="pt-BR"
          style={{ height: '100%' }}
          step={30}
          timeslots={2}
          min={new Date(0, 0, 0, 7, 0)}
          max={new Date(0, 0, 0, 22, 0)}
          popup
        />
      </div>

      {/* Modal */}
      {modalOpen && (
        <AppointmentModal
          appointment={selectedApt}
          slotInfo={slotInfo}
          onClose={() => setModalOpen(false)}
          onSuccess={() => {
            setModalOpen(false);
            qc.invalidateQueries({ queryKey: ['appointments'] });
            toast.success(selectedApt ? 'Agendamento atualizado!' : 'Agendamento criado!');
          }}
        />
      )}
    </div>
  );
}
