import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ReviewsService {
  constructor(private prisma: PrismaService) {}

  async findAll(barbershopId: string, { page = 1, limit = 20 }: any = {}) {
    const where = { barbershopId };
    const [total, items] = await Promise.all([
      this.prisma.review.count({ where }),
      this.prisma.review.findMany({
        where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: +limit,
        include: { client: { select: { name: true } }, appointment: { include: { service: true } } },
      }),
    ]);
    const avgRating = await this.prisma.review.aggregate({ where, _avg: { rating: true } });
    return { total, items, avgRating: avgRating._avg.rating || 0 };
  }

  async create(dto: any) {
    return this.prisma.review.create({ data: dto, include: { client: true } });
  }

  async respond(barbershopId: string, id: string, response: string) {
    return this.prisma.review.updateMany({ where: { id, barbershopId }, data: { response } });
  }
}
