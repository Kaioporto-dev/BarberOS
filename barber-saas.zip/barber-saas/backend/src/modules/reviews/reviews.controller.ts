import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ReviewsService } from './reviews.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('reviews')
@Controller({ path: 'reviews', version: '1' })
export class ReviewsController {
  constructor(private readonly svc: ReviewsService) {}

  @Get()
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  findAll(@CurrentUser() u: any, @Query() q: any) { return this.svc.findAll(u.barbershopId, q); }

  @Post()
  create(@Body() dto: any) { return this.svc.create(dto); }

  @Patch(':id/respond')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  respond(@CurrentUser() u: any, @Param('id') id: string, @Body('response') response: string) {
    return this.svc.respond(u.barbershopId, id, response);
  }
}
